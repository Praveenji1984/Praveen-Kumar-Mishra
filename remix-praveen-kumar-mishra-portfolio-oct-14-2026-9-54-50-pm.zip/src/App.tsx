import React, { useState, useEffect } from 'react';
import { Language } from './types';
import { Header } from './components/Header';
import { HomePage } from './components/HomePage';
import { PageHeaderBanner } from './components/PageHeaderBanner';
import { About } from './components/About';
import { PoliticalProfile } from './components/PoliticalProfile';
import { VisionKasganj } from './components/VisionKasganj';
import { ElectionRoadmap2027 } from './components/ElectionRoadmap2027';
import { VolunteerRegistration } from './components/VolunteerRegistration';
import { ImpactStoriesSection } from './components/ImpactStoriesSection';
import { SocialWork } from './components/SocialWork';
import { TrustSection } from './components/TrustSection';
import { PublicIssues } from './components/PublicIssues';
import { Initiatives } from './components/Initiatives';
import { ProfessionalExperience } from './components/ProfessionalExperience';
import { EducationSkills } from './components/EducationSkills';
import { Gallery } from './components/Gallery';
import { VideosSection } from './components/VideosSection';
import { MediaSection } from './components/MediaSection';
import { SocialMediaSection } from './components/SocialMediaSection';
import { CommunityNewsletter } from './components/CommunityNewsletter';
import { DonationSection } from './components/DonationSection';
import { ContactSection } from './components/ContactSection';
import { PhotoStudioPage } from './components/PhotoStudioPage';
import { Footer } from './components/Footer';
import { AiJanSamvadModal } from './components/AiJanSamvadModal';
import { AiCareerAdvisorModal } from './components/AiCareerAdvisorModal';
import { PhotoStudioModal } from './components/PhotoStudioModal';
import { Bot, ArrowLeft, ArrowRight, Compass } from 'lucide-react';
import { PageId, PAGE_CONFIG, resolvePageFromHash } from './data/pageConfig';

export default function App() {
  const [lang, setLang] = useState<Language>('en');
  const [activePage, setActivePage] = useState<PageId>(() => {
    if (typeof window !== 'undefined' && window.location.hash) {
      return resolvePageFromHash(window.location.hash);
    }
    return 'home';
  });

  const [isAiChatOpen, setIsAiChatOpen] = useState(false);
  const [isAiCareerOpen, setIsAiCareerOpen] = useState(false);
  const [isPhotoStudioModalOpen, setIsPhotoStudioModalOpen] = useState(false);

  // Sync title dynamically based on language choice and active page
  useEffect(() => {
    const pageMeta = PAGE_CONFIG[activePage];
    const pageTitle = lang === 'hi' ? pageMeta?.labelHi : pageMeta?.labelEn;
    const baseName = lang === 'hi' ? 'प्रवीण कुमार मिश्र' : 'Praveen Kumar Mishra';

    if (activePage === 'home') {
      document.title =
        lang === 'hi'
          ? 'प्रवीण कुमार मिश्र | सामाजिक कार्यकर्ता | जनजीवन | कासगंज'
          : 'Praveen Kumar Mishra | Social Worker | Public Life | Kasganj';
    } else {
      document.title = `${pageTitle} | ${baseName} | Kasganj`;
    }
  }, [lang, activePage]);

  // Handle browser back/forward and URL hash updates
  useEffect(() => {
    const handleHashChange = () => {
      const targetPage = resolvePageFromHash(window.location.hash);
      setActivePage(targetPage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    };

    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const handleNavigate = (page: PageId) => {
    setActivePage(page);
    const targetHash = PAGE_CONFIG[page]?.hash || '';
    if (window.location.hash.replace(/^#/, '') !== targetHash) {
      window.location.hash = targetHash === 'home' ? '' : `#${targetHash}`;
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleLanguage = () => {
    setLang((prev) => (prev === 'en' ? 'hi' : 'en'));
  };

  // Quick next/related pages helper for subpage bottom recommendations
  const getRelatedPages = (current: PageId): PageId[] => {
    const allPages: PageId[] = [
      'about',
      'public-role',
      'vision-2027',
      'impact-proof',
      'roadmap-2027',
      'social-work',
      'public-issues',
      'initiatives',
      'ambedkar-trust',
      'experience',
      'education-skills',
      'gallery',
      'speeches-videos',
      'media-updates',
      'volunteer',
      'campaign-fund',
      'newsletter',
      'contact',
      'photo-studio',
    ];
    const currentIndex = allPages.indexOf(current);
    if (currentIndex === -1) return ['about', 'vision-2027', 'contact'];

    const next1 = allPages[(currentIndex + 1) % allPages.length];
    const next2 = allPages[(currentIndex + 2) % allPages.length];
    return [next1, next2];
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans selection:bg-amber-100 selection:text-amber-900">
      {/* 3-Zone Top Navigation with 20 Dedicated Page Links */}
      <Header
        lang={lang}
        activePage={activePage}
        onNavigate={handleNavigate}
        onToggleLang={toggleLanguage}
        onOpenAiChat={() => setIsAiChatOpen(true)}
        onOpenPhotoStudio={() => handleNavigate('photo-studio')}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {activePage === 'home' ? (
          /* HOMEPAGE: Clean standard website layout with About Us summary, teasers, and CTAs */
          <HomePage
            lang={lang}
            onNavigate={handleNavigate}
            onOpenAiChat={() => setIsAiChatOpen(true)}
            onOpenPhotoStudio={() => handleNavigate('photo-studio')}
          />
        ) : (
          /* DEDICATED SEPARATE PAGES: Full in-depth content for each keyword */
          <div className="space-y-0">
            {/* Subpage Breadcrumb & Header Banner */}
            <PageHeaderBanner
              pageId={activePage}
              lang={lang}
              onNavigate={handleNavigate}
            />

            {/* Dedicated Page Render based on activePage */}
            {activePage === 'about' && <About lang={lang} />}
            {activePage === 'public-role' && <PoliticalProfile lang={lang} />}
            {activePage === 'vision-2027' && <VisionKasganj lang={lang} />}
            {activePage === 'impact-proof' && <ImpactStoriesSection lang={lang} />}
            {activePage === 'roadmap-2027' && <ElectionRoadmap2027 lang={lang} />}
            {activePage === 'social-work' && <SocialWork lang={lang} />}
            {activePage === 'public-issues' && <PublicIssues lang={lang} />}
            {activePage === 'newsletter' && <CommunityNewsletter lang={lang} />}
            {activePage === 'volunteer' && <VolunteerRegistration lang={lang} />}
            {activePage === 'initiatives' && <Initiatives lang={lang} />}
            {activePage === 'campaign-fund' && <DonationSection lang={lang} />}
            {activePage === 'ambedkar-trust' && <TrustSection lang={lang} />}
            {activePage === 'experience' && <ProfessionalExperience lang={lang} />}
            {activePage === 'education-skills' && (
              <EducationSkills
                lang={lang}
                onOpenCareerAdvisor={() => setIsAiCareerOpen(true)}
              />
            )}
            {activePage === 'gallery' && <Gallery lang={lang} />}
            {activePage === 'speeches-videos' && <VideosSection lang={lang} />}
            {activePage === 'media-updates' && <MediaSection lang={lang} />}
            {activePage === 'social-media' && <SocialMediaSection lang={lang} />}
            {activePage === 'contact' && <ContactSection lang={lang} />}
            {activePage === 'photo-studio' && <PhotoStudioPage lang={lang} />}

            {/* Subpage Footer Navigation / Related Pages */}
            <div className="bg-slate-100 border-t border-slate-200 py-10">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                  <button
                    onClick={() => handleNavigate('home')}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-white hover:bg-slate-50 text-slate-800 text-xs sm:text-sm font-bold border border-slate-300 shadow-xs transition-colors cursor-pointer"
                  >
                    <ArrowLeft className="w-4 h-4 text-amber-600" />
                    <span>{lang === 'hi' ? 'मुख्य पृष्ठ पर वापस' : 'Back to Homepage'}</span>
                  </button>

                  <div className="flex items-center gap-3 flex-wrap justify-center">
                    <span className="text-xs text-slate-500 font-medium">
                      {lang === 'hi' ? 'अन्य अनुभाग देखें:' : 'Explore Next:'}
                    </span>
                    {getRelatedPages(activePage).map((relatedId) => {
                      const relMeta = PAGE_CONFIG[relatedId];
                      return (
                        <button
                          key={relatedId}
                          onClick={() => handleNavigate(relatedId)}
                          className="px-3.5 py-1.5 rounded-lg bg-blue-950 text-white text-xs font-semibold hover:bg-blue-900 transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <span>{lang === 'hi' ? relMeta.labelHi : relMeta.labelEn}</span>
                          <ArrowRight className="w-3 h-3 text-amber-400" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Dignified Footer with Page Links */}
      <Footer lang={lang} onNavigate={handleNavigate} />

      {/* Floating Action Button: AI Jan Samvad Assistant */}
      <button
        onClick={() => setIsAiChatOpen(true)}
        className="fixed bottom-6 right-6 z-40 p-3.5 bg-gradient-to-r from-blue-900 via-indigo-900 to-blue-950 text-white border border-amber-400/40 rounded-full shadow-2xl hover:scale-105 transition-all flex items-center justify-center cursor-pointer group"
        aria-label="Open Praveen AI Assistant"
        title="Open Praveen Jan Samvad AI / एआई जनसंवाद"
      >
        <Bot className="w-6 h-6 text-amber-400" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap text-xs font-bold pl-0 group-hover:pl-2">
          {lang === 'hi' ? 'प्रवीण जनसंवाद एआई' : 'Praveen AI'}
        </span>
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full border-2 border-slate-900 animate-pulse" />
      </button>

      {/* Modals */}
      <AiJanSamvadModal
        isOpen={isAiChatOpen}
        onClose={() => setIsAiChatOpen(false)}
        lang={lang}
      />

      <AiCareerAdvisorModal
        isOpen={isAiCareerOpen}
        onClose={() => setIsAiCareerOpen(false)}
        lang={lang}
      />

      <PhotoStudioModal
        isOpen={isPhotoStudioModalOpen}
        onClose={() => setIsPhotoStudioModalOpen(false)}
        lang={lang}
      />
    </div>
  );
}
