import type { PhotoSettings } from '../types';
import { DEFAULT_PHOTO_SETTINGS } from '../types';

export { DEFAULT_PHOTO_SETTINGS };
export type { PhotoSettings };

export interface PhotoPresetItem {
  id: string;
  filename: string;
  nameEn: string;
  nameHi: string;
  category: 'portrait' | 'presidential' | 'youth' | 'rally' | 'office' | 'public_hearing' | 'harmony';
  slot: 'hero' | 'presidential' | 'youth' | 'rally' | 'office' | 'gallery';
  defaultAspectRatio: '3/4' | '1/1' | '4/3' | '16/9' | '9/16' | '2/3';
  quoteHi: string;
  quoteEn: string;
  descriptionHi: string;
  descriptionEn: string;
  defaultZoom: number;
  defaultPositionX: number;
  defaultPositionY: number;
  shape: 'rounded' | 'circle' | 'card';
  showGoldBorder: boolean;
  borderStyle: 'gold' | 'navy' | 'tricolor' | 'none';
  svgDataUri: string;
}

// Pre-packaged high-fidelity SVG depictions matching the 7 uploaded photos
export const PHOTO_PRESETS: PhotoPresetItem[] = [
  {
    id: 'preset-hero-c7bar',
    filename: 'C7BAR.jpg',
    nameEn: 'Official Blue Blazer Portrait (C7BAR)',
    nameHi: 'आधिकारिक ब्लू ब्लेज़र पोट्रेट (C7BAR)',
    category: 'portrait',
    slot: 'hero',
    defaultAspectRatio: '3/4',
    quoteHi: 'कासगंज के विकास और लोगों की सेवा ही मेरा उद्देश्य है।',
    quoteEn: 'Development of Kasganj and service of the people is my sole purpose.',
    descriptionHi: 'नेवी ब्लू ब्लेज़र, सफेद कॉलर शर्ट, कलाई पर कलावा (मौली) और सौम्य आत्मविश्वासी मुस्कान के साथ आधिकारिक पोट्रेट।',
    descriptionEn: 'Official executive portrait in navy blazer, white collared shirt, sacred kalava thread on wrist, and inspiring warm smile.',
    defaultZoom: 105,
    defaultPositionX: 50,
    defaultPositionY: 25,
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'gold',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="100%" height="100%">
        <defs>
          <radialGradient id="bgGrad" cx="50%" cy="40%" r="70%">
            <stop offset="0%" stop-color="#2a3f5f"/>
            <stop offset="45%" stop-color="#162238"/>
            <stop offset="100%" stop-color="#090d16"/>
          </radialGradient>
          <radialGradient id="bokeh1" cx="30%" cy="20%" r="30%">
            <stop offset="0%" stop-color="#f59e0b" stop-opacity="0.35"/>
            <stop offset="100%" stop-color="#f59e0b" stop-opacity="0"/>
          </radialGradient>
          <radialGradient id="bokeh2" cx="80%" cy="30%" r="25%">
            <stop offset="0%" stop-color="#fbbf24" stop-opacity="0.25"/>
            <stop offset="100%" stop-color="#fbbf24" stop-opacity="0"/>
          </radialGradient>
          <linearGradient id="suitGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#1e2c4f"/>
            <stop offset="50%" stop-color="#121d36"/>
            <stop offset="100%" stop-color="#0a1020"/>
          </linearGradient>
          <linearGradient id="goldRim" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#f59e0b"/>
            <stop offset="50%" stop-color="#fef3c7"/>
            <stop offset="100%" stop-color="#d97706"/>
          </linearGradient>
        </defs>

        <rect width="600" height="800" fill="url(#bgGrad)"/>
        <circle cx="180" cy="180" r="160" fill="url(#bokeh1)"/>
        <circle cx="480" cy="220" r="140" fill="url(#bokeh2)"/>
        <circle cx="100" cy="350" r="100" fill="url(#bokeh2)"/>

        <!-- Navy Blazer Shoulders -->
        <path d="M120 540 C140 440, 240 410, 300 410 C360 410, 460 440, 480 540 L520 800 L80 800 Z" fill="url(#suitGrad)"/>
        <!-- White Shirt V-neck -->
        <path d="M255 410 L300 520 L345 410 Z" fill="#ffffff"/>
        <path d="M295 440 L300 620 L305 620 L300 440" stroke="#cbd5e1" stroke-width="2"/>
        <!-- Blazer Lapels -->
        <path d="M220 440 L285 550 L270 660 L180 580 Z" fill="#182544" stroke="#253866" stroke-width="2"/>
        <path d="M380 440 L315 550 L330 660 L420 580 Z" fill="#182544" stroke="#253866" stroke-width="2"/>

        <!-- Neck -->
        <path d="M260 360 C260 410, 340 410, 340 360 Z" fill="#c68a62"/>

        <!-- Head / Face -->
        <ellipse cx="300" cy="290" rx="90" ry="110" fill="#df9b6d"/>
        <path d="M225 310 C230 400, 300 420, 300 420 C300 420, 370 400, 375 310 Z" fill="#d49063"/>

        <!-- Hair -->
        <path d="M200 270 C190 190, 260 160, 300 160 C360 160, 410 190, 400 270 C380 220, 350 200, 300 200 C250 200, 220 220, 200 270 Z" fill="#171717"/>
        <path d="M205 240 C210 200, 280 170, 320 180 C360 190, 395 210, 395 250 C380 215, 340 200, 310 205 C270 210, 230 225, 205 240 Z" fill="#262626"/>

        <!-- Eyebrows -->
        <path d="M235 255 Q260 248 275 255" stroke="#171717" stroke-width="5" stroke-linecap="round" fill="none"/>
        <path d="M325 255 Q340 248 365 255" stroke="#171717" stroke-width="5" stroke-linecap="round" fill="none"/>

        <!-- Eyes -->
        <ellipse cx="255" cy="270" rx="14" ry="8" fill="#ffffff"/>
        <circle cx="256" cy="270" r="5" fill="#2d1a0e"/>
        <circle cx="258" cy="268" r="1.5" fill="#ffffff"/>

        <ellipse cx="345" cy="270" rx="14" ry="8" fill="#ffffff"/>
        <circle cx="344" cy="270" r="5" fill="#2d1a0e"/>
        <circle cx="346" cy="268" r="1.5" fill="#ffffff"/>

        <!-- Nose -->
        <path d="M298 260 L295 305 Q300 315 305 305 Z" fill="#c37d52"/>

        <!-- Warm Smile -->
        <path d="M270 335 Q300 360 330 335" stroke="#831843" stroke-width="4" stroke-linecap="round" fill="none"/>
        <path d="M275 337 Q300 350 325 337" fill="#ffffff"/>

        <!-- Hand resting under chin with Kalava (Red Sacred Thread) -->
        <path d="M260 480 C270 430, 290 415, 305 415 C320 415, 330 435, 320 470 Z" fill="#df9b6d"/>
        <rect x="272" y="450" width="36" height="8" rx="3" fill="#dc2626"/>
        <line x1="272" y1="454" x2="308" y2="454" stroke="#facc15" stroke-width="1.5"/>

        <!-- Gold Border Frame -->
        <rect x="15" y="15" width="570" height="770" rx="28" fill="none" stroke="url(#goldRim)" stroke-width="3" opacity="0.8"/>

        <!-- Quote Card at Bottom -->
        <rect x="35" y="660" width="530" height="105" rx="18" fill="#090d16" fill-opacity="0.88" stroke="#f59e0b" stroke-width="1.5"/>
        <text x="300" y="700" font-family="'Noto Sans Devanagari', sans-serif" font-size="20" font-weight="bold" fill="#ffffff" text-anchor="middle">
          "कासगंज के विकास और लोगों की सेवा ही मेरा उद्देश्य है।"
        </text>
        <text x="300" y="732" font-family="'Plus Jakarta Sans', sans-serif" font-size="14" font-weight="600" fill="#f59e0b" text-anchor="middle">
          प्रवीण कुमार मिश्र | 100 - कासगंज विधानसभा
        </text>
      </svg>
    `)}`,
  },
  {
    id: 'preset-presidential-kovind',
    filename: 'WhatsApp Image 2026-02-22 at 2.03.17 PM.jpeg',
    nameEn: 'Meeting with Former President Shri Ram Nath Kovind',
    nameHi: 'पूर्व राष्ट्रपति महामहिम रामनाथ कोविंद जी से भेंट',
    category: 'presidential',
    slot: 'presidential',
    defaultAspectRatio: '1/1',
    quoteHi: 'राष्ट्र सेवा, संवैधानिक मूल्य और कासगंज के जनकल्याण पर आदरणीय पूर्व राष्ट्रपति जी का मार्गदर्शन।',
    quoteEn: 'Blessings and dialogue on national service, constitutional values, and rural welfare.',
    descriptionHi: 'भारत के 14वें राष्ट्रपति महामहिम श्री रामनाथ कोविंद जी के साथ राष्ट्रीय ध्वज तिरंगा के समक्ष गरिमामयी भेंट व संवाद।',
    descriptionEn: 'High-stature meeting seated alongside the 14th President of India Shri Ram Nath Kovind ji with the National Tricolor Flag.',
    defaultZoom: 100,
    defaultPositionX: 50,
    defaultPositionY: 45,
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'gold',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="100%" height="100%">
        <defs>
          <linearGradient id="presidentialWall" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#fdfbf7"/>
            <stop offset="100%" stop-color="#ede7db"/>
          </linearGradient>
          <linearGradient id="tirangaSaffron" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#ff9933"/>
            <stop offset="100%" stop-color="#f27d0c"/>
          </linearGradient>
          <linearGradient id="tirangaGreen" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#138808"/>
            <stop offset="100%" stop-color="#0e6306"/>
          </linearGradient>
          <linearGradient id="goldCarving" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#d97706"/>
            <stop offset="50%" stop-color="#fbbf24"/>
            <stop offset="100%" stop-color="#b45309"/>
          </linearGradient>
        </defs>

        <rect width="800" height="800" fill="url(#presidentialWall)"/>
        <rect x="0" y="0" width="80" height="800" fill="#e2d9c8" opacity="0.6"/>
        <rect x="720" y="0" width="80" height="800" fill="#e2d9c8" opacity="0.6"/>

        <!-- Indian National Flag in Center -->
        <g id="NationalFlag" transform="translate(325, 40)">
          <rect x="72" y="0" width="6" height="420" fill="#d4af37" rx="3"/>
          <circle cx="75" cy="5" r="9" fill="#f59e0b"/>
          <path d="M78 20 C120 15, 160 30, 205 20 L205 85 C160 95, 120 80, 78 85 Z" fill="url(#tirangaSaffron)"/>
          <path d="M78 85 C120 80, 160 95, 205 85 L205 150 C160 160, 120 145, 78 150 Z" fill="#ffffff"/>
          <path d="M78 150 C120 145, 160 160, 205 150 L205 215 C160 225, 120 210, 78 215 Z" fill="url(#tirangaGreen)"/>
          <circle cx="140" cy="118" r="18" fill="none" stroke="#000088" stroke-width="2"/>
          <circle cx="140" cy="118" r="3" fill="#000088"/>
          <line x1="140" y1="100" x2="140" y2="136" stroke="#000088" stroke-width="1.2"/>
          <line x1="122" y1="118" x2="158" y2="118" stroke="#000088" stroke-width="1.2"/>
        </g>

        <!-- Ceremonial High-Backed Armchairs -->
        <rect x="80" y="280" width="280" height="450" rx="20" fill="#f5edd6" stroke="url(#goldCarving)" stroke-width="6"/>
        <rect x="110" y="310" width="220" height="240" rx="14" fill="#faf6eb" stroke="#d5c7a3" stroke-width="2"/>
        <rect x="440" y="280" width="280" height="450" rx="20" fill="#f5edd6" stroke="url(#goldCarving)" stroke-width="6"/>
        <rect x="470" y="310" width="220" height="240" rx="14" fill="#faf6eb" stroke="#d5c7a3" stroke-width="2"/>

        <!-- Left Figure: Shri Ram Nath Kovind ji -->
        <path d="M120 380 C150 320, 290 320, 320 380 L340 700 L100 700 Z" fill="#1e2229"/>
        <ellipse cx="220" cy="260" rx="55" ry="68" fill="#d29065"/>
        <rect x="185" y="245" width="30" height="20" rx="5" fill="none" stroke="#475569" stroke-width="3"/>
        <rect x="225" y="245" width="30" height="20" rx="5" fill="none" stroke="#475569" stroke-width="3"/>
        <line x1="215" y1="255" x2="225" y2="255" stroke="#475569" stroke-width="3"/>
        <ellipse cx="220" cy="530" rx="50" ry="25" fill="#c48259"/>

        <!-- Right Figure: Praveen Kumar Mishra ji -->
        <path d="M480 380 C510 320, 650 320, 680 380 L700 700 L460 700 Z" fill="#2d2b27"/>
        <path d="M510 380 L650 380 L640 680 L520 680 Z" fill="#3a362f" stroke="#4b463d" stroke-width="2"/>
        <ellipse cx="580" cy="260" rx="58" ry="70" fill="#df9b6d"/>
        <path d="M520 250 C510 180, 580 160, 620 170 C650 180, 645 230, 640 250 C620 210, 590 195, 550 205 C530 215, 525 230, 520 250 Z" fill="#1c1917"/>
        <path d="M555 295 Q580 315 605 295" stroke="#991b1b" stroke-width="3" stroke-linecap="round" fill="none"/>
        <circle cx="550" cy="245" r="4.5" fill="#262626"/>
        <circle cx="610" cy="245" r="4.5" fill="#262626"/>
        <ellipse cx="580" cy="540" rx="52" ry="26" fill="#d49063"/>
        <rect x="548" y="535" width="20" height="6" rx="2" fill="#dc2626"/>

        <!-- Plaque Banner at Bottom -->
        <rect x="40" y="680" width="720" height="96" rx="18" fill="#0f172a" fill-opacity="0.94" stroke="#f59e0b" stroke-width="2"/>
        <text x="400" y="718" font-family="'Noto Sans Devanagari', sans-serif" font-size="20" font-weight="bold" fill="#fef3c7" text-anchor="middle">
          पूर्व राष्ट्रपति महामहिम श्री रामनाथ कोविंद जी से शिष्टाचार भेंट
        </text>
        <text x="400" y="750" font-family="'Plus Jakarta Sans', sans-serif" font-size="14" font-weight="600" fill="#94a3b8" text-anchor="middle">
          Praveen Kumar Mishra with 14th President of India | National Leadership Milestone
        </text>
      </svg>
    `)}`,
  },
  {
    id: 'preset-youth-mentorship',
    filename: 'eg.jpeg',
    nameEn: 'Youth Skill & Education Mentorship Round-table',
    nameHi: 'युवा संवाद, उच्च शिक्षा एवं करियर मार्गदर्शन',
    category: 'youth',
    slot: 'youth',
    defaultAspectRatio: '4/3',
    quoteHi: 'कासगंज के शिक्षित युवाओं को स्थानीय स्तर पर रोजगार व सम्मानजनक जीवन दिलाना ही हमारा मुख्य संकल्प है।',
    quoteEn: 'Mentoring Kasganj youth for competitive excellence, ITI skills, and local careers.',
    descriptionHi: 'हाथ में खुली डायरी, क्रीम नेहरू जैकेट और मेज पर माइक के साथ युवा छात्र-छात्राओं को रोजगार व प्रतियोगी परीक्षाओं का मार्गदर्शन देते हुए।',
    descriptionEn: 'Conducting career counseling round-table in ivory Nehru jacket with notebooks, microphone, and educated students.',
    defaultZoom: 105,
    defaultPositionX: 50,
    defaultPositionY: 30,
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'navy',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" width="100%" height="100%">
        <defs>
          <linearGradient id="gardenBg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#2d3748"/>
            <stop offset="100%" stop-color="#1a202c"/>
          </linearGradient>
          <linearGradient id="nehruJacket" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#fef3c7"/>
            <stop offset="100%" stop-color="#fde68a"/>
          </linearGradient>
        </defs>

        <rect width="800" height="600" fill="url(#gardenBg)"/>
        <circle cx="200" cy="120" r="180" fill="#234e32" opacity="0.4"/>
        <circle cx="650" cy="140" r="190" fill="#234e32" opacity="0.4"/>

        <!-- Surrounding Students & Youths in suits -->
        <circle cx="120" cy="180" r="45" fill="#d97706"/>
        <rect x="60" y="230" width="120" height="150" rx="20" fill="#1e3a8a"/>
        <circle cx="270" cy="160" r="48" fill="#d97706"/>
        <rect x="210" y="210" width="120" height="150" rx="20" fill="#1e3a8a"/>
        <circle cx="470" cy="160" r="48" fill="#d97706"/>
        <rect x="410" y="210" width="120" height="150" rx="20" fill="#1e3a8a"/>
        <circle cx="680" cy="190" r="45" fill="#d97706"/>
        <rect x="620" y="240" width="120" height="150" rx="20" fill="#1e3a8a"/>

        <!-- Center Key Leader: Praveen Kumar Mishra in Ivory/Cream Nehru Jacket -->
        <path d="M300 240 C350 210, 470 210, 520 240 L560 480 L260 480 Z" fill="url(#nehruJacket)"/>
        <circle cx="410" cy="280" r="5" fill="#b45309"/>
        <circle cx="410" cy="320" r="5" fill="#b45309"/>
        <circle cx="410" cy="360" r="5" fill="#b45309"/>
        <ellipse cx="410" cy="155" rx="65" ry="78" fill="#df9b6d"/>
        <path d="M340 140 C335 70, 420 50, 470 65 C495 80, 490 130, 480 145 C460 105, 430 90, 390 100 C365 110, 350 120, 340 140 Z" fill="#171717"/>
        <circle cx="380" cy="145" r="4.5" fill="#1f2937"/>
        <circle cx="440" cy="145" r="4.5" fill="#1f2937"/>
        <path d="M390 190 Q410 205 435 190" stroke="#991b1b" stroke-width="3" stroke-linecap="round" fill="none"/>

        <!-- Conference Table with White Tablecloth -->
        <path d="M80 430 L720 430 L800 600 L0 600 Z" fill="#ffffff" stroke="#e2e8f0" stroke-width="3"/>
        <polygon points="350,440 470,440 490,490 330,490" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2"/>
        <rect x="300" y="460" width="50" height="12" rx="6" fill="#1e293b"/>
        <circle cx="300" cy="466" r="9" fill="#0f172a" stroke="#475569" stroke-width="2"/>
        <circle cx="560" cy="465" r="22" fill="#fef08a" stroke="#f59e0b" stroke-width="2"/>

        <!-- Bottom Banner -->
        <rect x="40" y="520" width="720" height="65" rx="14" fill="#0f172a" fill-opacity="0.92" stroke="#3b82f6" stroke-width="1.5"/>
        <text x="400" y="548" font-family="'Noto Sans Devanagari', sans-serif" font-size="17" font-weight="bold" fill="#ffffff" text-anchor="middle">
          राघव फाउंडेशन व ट्रस्ट द्वारा आयोजित युवा हुनर व करियर संवाद
        </text>
        <text x="400" y="572" font-family="'Plus Jakarta Sans', sans-serif" font-size="12" font-weight="600" fill="#93c5fd" text-anchor="middle">
          Praveen Kumar Mishra Mentoring Kasganj Youth for Careers & Self-Reliance
        </text>
      </svg>
    `)}`,
  },
  {
    id: 'preset-rally-speech-3png',
    filename: '3.png',
    nameEn: 'Kasganj Public Rally & Speech (3.png)',
    nameHi: 'कासगंज विशाल जनसभा एवं जनसंवाद (3.png)',
    category: 'rally',
    slot: 'rally',
    defaultAspectRatio: '9/16',
    quoteHi: 'मेहनत, ईमानदारी और जनसेवा — इन तीन चीजों पर मेरा विश्वास है। कासगंज के लिए यही मेरा मंत्र है। #कासगंज',
    quoteEn: 'Hard work, honesty and public service — these three are my creed. This is my mantra for Kasganj.',
    descriptionHi: 'सफेद कुर्ता, तिरंगा अंगवस्त्रम, माइक पर ओजस्वी वक्तव्य और ऐतिहासिक कासगंज प्रवेश द्वार प्रतीक के साथ विशाल जनसभा।',
    descriptionEn: 'Inspiring podium speech in white kurta and tricolor scarf addressing thousands at Kasganj public assembly.',
    defaultZoom: 100,
    defaultPositionX: 50,
    defaultPositionY: 30,
    shape: 'card',
    showGoldBorder: true,
    borderStyle: 'tricolor',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 1060" width="100%" height="100%">
        <defs>
          <linearGradient id="posterBg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#ff7700"/>
            <stop offset="18%" stop-color="#1e3a8a"/>
            <stop offset="100%" stop-color="#0a192f"/>
          </linearGradient>
          <linearGradient id="goldBorder" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#f59e0b"/>
            <stop offset="100%" stop-color="#d97706"/>
          </linearGradient>
        </defs>

        <rect width="600" height="1060" fill="url(#posterBg)"/>
        <path d="M0 0 L600 0 L600 120 L0 180 Z" fill="#ff6b00" opacity="0.85"/>

        <!-- Praveen Mishra - Rally Orator in White Kurta & Tricolor Scarf -->
        <ellipse cx="330" cy="230" rx="72" ry="88" fill="#df9b6d"/>
        <path d="M255 210 C250 140, 340 110, 400 130 C430 150, 420 200, 410 220 C390 180, 360 160, 310 170 C280 180, 265 195, 255 210 Z" fill="#171717"/>
        <circle cx="295" cy="220" r="5" fill="#1f2937"/>
        <circle cx="365" cy="220" r="5" fill="#1f2937"/>
        <path d="M310 270 Q335 290 360 270" stroke="#991b1b" stroke-width="4" stroke-linecap="round" fill="none"/>

        <!-- White Kurta & Tricolor Scarf -->
        <path d="M160 380 C210 320, 450 320, 500 380 L520 540 L140 540 Z" fill="#f8fafc"/>
        <path d="M230 330 C250 360, 260 480, 265 540 L240 540 C235 480, 225 360, 205 330 Z" fill="#ff9933"/>
        <path d="M250 330 C270 360, 280 480, 285 540 L265 540 C260 480, 250 360, 230 330 Z" fill="#ffffff"/>
        <path d="M270 330 C290 360, 300 480, 305 540 L285 540 C280 480, 270 360, 250 330 Z" fill="#138808"/>

        <!-- Rally Microphones with Red Bands -->
        <rect x="380" y="320" width="18" height="60" rx="9" fill="#1e293b"/>
        <circle cx="389" cy="320" r="14" fill="#0f172a" stroke="#dc2626" stroke-width="3"/>
        <rect x="430" y="335" width="18" height="60" rx="9" fill="#1e293b"/>
        <circle cx="439" cy="335" r="14" fill="#0f172a" stroke="#dc2626" stroke-width="3"/>

        <!-- Deep Blue Base with Large Hindi Typography -->
        <rect x="25" y="520" width="550" height="500" rx="20" fill="#0c1a32" stroke="url(#goldBorder)" stroke-width="2"/>
        <text x="50" y="580" font-family="'Noto Sans Devanagari', sans-serif" font-size="34" font-weight="900" fill="#ff7700">
          मेहनत, ईमानदारी और
        </text>
        <text x="50" y="630" font-family="'Noto Sans Devanagari', sans-serif" font-size="34" font-weight="900" fill="#ff7700">
          जनसेवा — इन तीन
        </text>
        <text x="50" y="680" font-family="'Noto Sans Devanagari', sans-serif" font-size="34" font-weight="900" fill="#ff7700">
          चीजों पर मेरा विश्वास है।
        </text>
        <text x="50" y="770" font-family="'Noto Sans Devanagari', sans-serif" font-size="30" font-weight="800" fill="#facc15">
          कासगंज के लिए
        </text>
        <text x="50" y="815" font-family="'Noto Sans Devanagari', sans-serif" font-size="30" font-weight="800" fill="#facc15">
          यही मेरा मंत्र है।
        </text>
        <rect x="50" y="870" width="220" height="58" rx="29" fill="#ffffff"/>
        <text x="160" y="910" font-family="'Noto Sans Devanagari', sans-serif" font-size="28" font-weight="900" fill="#0f172a" text-anchor="middle">
          #कासगंज
        </text>
      </svg>
    `)}`,
  },
  {
    id: 'preset-office-9png',
    filename: '9.png',
    nameEn: 'Executive Study & Principle (9.png)',
    nameHi: 'कार्यालय एवं सिद्धांत – "कुर्सी अस्थायी है..." (9.png)',
    category: 'office',
    slot: 'office',
    defaultAspectRatio: '3/4',
    quoteHi: 'कुर्सी अस्थायी है, सेवा स्थायी होनी चाहिए।',
    quoteEn: 'Positions are temporary, service must be permanent.',
    descriptionHi: 'कार्यालय में लैपटॉप व अध्ययन पुस्तकों के साथ, नेवी बंडी व सफेद कुर्ता, पृष्ठभूमि में अशोक चक्र का प्रेरणादायी प्रतीक।',
    descriptionEn: 'At executive office desk with laptop and research books, featuring the Ashok Chakra watermark.',
    defaultZoom: 105,
    defaultPositionX: 50,
    defaultPositionY: 25,
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'gold',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="100%" height="100%">
        <defs>
          <linearGradient id="officeRoom" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#1e293b"/>
            <stop offset="100%" stop-color="#0f172a"/>
          </linearGradient>
        </defs>

        <rect width="600" height="800" fill="url(#officeRoom)"/>

        <!-- Ashoka Chakra Watermark -->
        <g stroke="#ffffff" stroke-width="1.5" fill="none" opacity="0.12" transform="translate(100, 100)">
          <circle cx="0" cy="0" r="70"/>
          <circle cx="0" cy="0" r="10"/>
          <line x1="-70" y1="0" x2="70" y2="0"/>
          <line x1="0" y1="-70" x2="0" y2="70"/>
        </g>

        <!-- Leader in White Kurta & Navy Bandhgala Jacket -->
        <path d="M120 480 C150 360, 450 360, 480 480 L510 650 L90 650 Z" fill="#ffffff"/>
        <path d="M170 480 C200 370, 400 370, 430 480 L445 650 L155 650 Z" fill="#0f172a" stroke="#1e293b" stroke-width="2"/>
        <ellipse cx="300" cy="250" rx="72" ry="86" fill="#df9b6d"/>
        <path d="M225 230 C220 150, 310 130, 370 145 C400 165, 395 210, 385 230 C365 195, 335 180, 290 190 C260 200, 240 215, 225 230 Z" fill="#171717"/>
        <circle cx="265" cy="235" r="4.5" fill="#1f2937"/>
        <circle cx="335" cy="235" r="4.5" fill="#1f2937"/>

        <!-- Desk & Quote -->
        <rect x="25" y="620" width="550" height="150" rx="20" fill="#0a1832" fill-opacity="0.96" stroke="#f59e0b" stroke-width="2"/>
        <text x="50" y="675" font-family="'Noto Sans Devanagari', sans-serif" font-size="34" font-weight="900" fill="#f59e0b">
          कुर्सी अस्थायी है,
        </text>
        <text x="50" y="730" font-family="'Noto Sans Devanagari', sans-serif" font-size="34" font-weight="900" fill="#ffffff">
          सेवा स्थायी होनी चाहिए।
        </text>
      </svg>
    `)}`,
  },
  {
    id: 'preset-harmony-lqawg',
    filename: 'LqawG.jpg',
    nameEn: 'Social Harmony & Vision (LqawG)',
    nameHi: 'सामाजिक समरसता – "जाति और धर्म से ऊपर..." (LqawG)',
    category: 'harmony',
    slot: 'gallery',
    defaultAspectRatio: '3/4',
    quoteHi: 'जाति और धर्म से ऊपर उठकर सिर्फ विकास की बात करनी चाहिए।',
    quoteEn: 'Rising above caste and religion, we must speak solely about development.',
    descriptionHi: 'नेवी ब्लेज़र सूट में प्रेरणादायी विचार, सद्भाव और सकारात्मक बदलाव का संदेश।',
    descriptionEn: 'Inspiring portrait in navy blazer calling for unified development free from caste and religious divisions.',
    defaultZoom: 105,
    defaultPositionX: 50,
    defaultPositionY: 25,
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'gold',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="100%" height="100%">
        <defs>
          <radialGradient id="harmonyBg" cx="50%" cy="35%" r="65%">
            <stop offset="0%" stop-color="#1e3a8a"/>
            <stop offset="50%" stop-color="#0f172a"/>
            <stop offset="100%" stop-color="#020617"/>
          </radialGradient>
        </defs>

        <rect width="600" height="800" fill="url(#harmonyBg)"/>
        <path d="M120 540 C140 440, 240 410, 300 410 C360 410, 460 440, 480 540 L520 800 L80 800 Z" fill="#172554"/>
        <ellipse cx="300" cy="290" rx="90" ry="110" fill="#df9b6d"/>
        <path d="M200 270 C190 190, 260 160, 300 160 C360 160, 410 190, 400 270 C380 220, 350 200, 300 200 C250 200, 220 220, 200 270 Z" fill="#171717"/>
        <circle cx="255" cy="270" r="5" fill="#1e293b"/>
        <circle cx="345" cy="270" r="5" fill="#1e293b"/>
        <rect x="272" y="445" width="36" height="8" rx="3" fill="#dc2626"/>

        <rect x="30" y="650" width="540" height="120" rx="20" fill="#020617" fill-opacity="0.92" stroke="#38bdf8" stroke-width="1.5"/>
        <text x="300" y="700" font-family="'Noto Sans Devanagari', sans-serif" font-size="22" font-weight="900" fill="#ffffff" text-anchor="middle">
          जाति और धर्म से ऊपर उठकर
        </text>
        <text x="300" y="736" font-family="'Noto Sans Devanagari', sans-serif" font-size="22" font-weight="900" fill="#facc15" text-anchor="middle">
          सिर्फ विकास की बात करनी चाहिए।
        </text>
      </svg>
    `)}`,
  },
  {
    id: 'preset-hearing-ppjpeg',
    filename: 'pp.jpeg',
    nameEn: 'Jan Samasya Public Hearing & Direct Redressal',
    nameHi: 'जनसुनवाई एवं क्षेत्रीय माताओं-बुजुर्गों से सीधा संवाद',
    category: 'public_hearing',
    slot: 'gallery',
    defaultAspectRatio: '3/4',
    quoteHi: 'जनता की हर समस्या का समाधान हमारी प्राथमिकता है।',
    quoteEn: 'Listening patiently to rural grievances and ensuring timely administrative resolution.',
    descriptionHi: 'डार्क सूट व महरून टाई में माइक हाथ में लिए ग्रामीणों, माताओं व बुजुर्गों की जनसुनवाई करते हुए।',
    descriptionEn: 'Addressing citizens and village elders with handheld microphone during local grievance redressal session.',
    defaultZoom: 105,
    defaultPositionX: 50,
    defaultPositionY: 28,
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'navy',
    svgDataUri: `data:image/svg+xml;utf8,${encodeURIComponent(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 800" width="100%" height="100%">
        <defs>
          <linearGradient id="hallBg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#334155"/>
            <stop offset="100%" stop-color="#0f172a"/>
          </linearGradient>
        </defs>

        <rect width="600" height="800" fill="url(#hallBg)"/>
        <path d="M140 480 C180 390, 420 390, 460 480 L490 800 L110 800 Z" fill="#0f172a"/>
        <polygon points="292,430 308,430 314,570 300,590 286,570" fill="#881337"/>
        <ellipse cx="300" cy="250" rx="78" ry="92" fill="#df9b6d"/>
        <circle cx="260" cy="240" r="5" fill="#1f2937"/>
        <circle cx="340" cy="240" r="5" fill="#1f2937"/>

        <rect x="330" y="310" width="22" height="70" rx="10" fill="#0f172a"/>
        <circle cx="341" cy="310" r="16" fill="#1e293b" stroke="#cbd5e1" stroke-width="1.5"/>

        <rect x="30" y="670" width="540" height="95" rx="16" fill="#0f172a" fill-opacity="0.94" stroke="#f59e0b" stroke-width="1.5"/>
        <text x="300" y="708" font-family="'Noto Sans Devanagari', sans-serif" font-size="20" font-weight="bold" fill="#ffffff" text-anchor="middle">
          जनसुनवाई: ग्रामीण माताओं एवं क्षेत्रवासियों से सीधा संवाद
        </text>
        <text x="300" y="740" font-family="'Plus Jakarta Sans', sans-serif" font-size="13" font-weight="600" fill="#f59e0b" text-anchor="middle">
          Direct Public Grievance Redressal | Praveen Kumar Mishra
        </text>
      </svg>
    `)}`,
  },
];
