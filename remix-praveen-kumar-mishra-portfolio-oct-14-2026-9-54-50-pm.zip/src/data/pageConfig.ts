import { LucideIcon } from 'lucide-react';

export type PageId =
  | 'home'
  | 'about'
  | 'public-role'
  | 'vision-2027'
  | 'impact-proof'
  | 'roadmap-2027'
  | 'social-work'
  | 'public-issues'
  | 'newsletter'
  | 'volunteer'
  | 'initiatives'
  | 'campaign-fund'
  | 'ambedkar-trust'
  | 'experience'
  | 'education-skills'
  | 'gallery'
  | 'speeches-videos'
  | 'media-updates'
  | 'social-media'
  | 'contact'
  | 'photo-studio';

export interface PageMeta {
  id: PageId;
  labelEn: string;
  labelHi: string;
  taglineEn: string;
  taglineHi: string;
  category: 'core' | 'vision' | 'service' | 'media' | 'engage' | 'tools';
  hash: string;
  aliases: string[];
}

export const PAGE_CONFIG: Record<PageId, PageMeta> = {
  home: {
    id: 'home',
    labelEn: 'Home',
    labelHi: 'मुख्य पृष्ठ',
    taglineEn: 'Welcome to the Official Portal of Praveen Kumar Mishra',
    taglineHi: 'प्रवीण कुमार मिश्र के आधिकारिक पोर्टल पर आपका स्वागत है',
    category: 'core',
    hash: 'home',
    aliases: ['', 'home', 'main'],
  },
  about: {
    id: 'about',
    labelEn: 'About',
    labelHi: 'परिचय',
    taglineEn: 'Biography, Roots in Kasganj, Philosophy & Public Service Record',
    taglineHi: 'जीवन परिचय, कासगंज की जड़ें, विचारधारा और जनसेवा यात्रा',
    category: 'core',
    hash: 'about',
    aliases: ['about', 'bio', 'biography'],
  },
  'public-role': {
    id: 'public-role',
    labelEn: 'Public Role',
    labelHi: 'सार्वजनिक दायित्व',
    taglineEn: 'Public Representation, Constitutional Values & Presidential Engagement',
    taglineHi: 'सार्वजनिक दायित्व, संवैधानिक मूल्य व महामहिम राष्ट्रपति जी से भेंट',
    category: 'core',
    hash: 'public-role',
    aliases: ['public-role', 'political-profile', 'public-life', 'leadership'],
  },
  'vision-2027': {
    id: 'vision-2027',
    labelEn: 'Vision 2027',
    labelHi: 'कासगंज विजन 2027',
    taglineEn: 'Holistic Blueprint for Vidhan Sabha 100 Kasganj Development',
    taglineHi: '100-कासगंज विधानसभा क्षेत्र के समग्र विकास का सशक्त रोडमैप',
    category: 'vision',
    hash: 'vision-2027',
    aliases: ['vision-2027', 'vision-kasganj', 'vision'],
  },
  'impact-proof': {
    id: 'impact-proof',
    labelEn: 'Impact & Proof',
    labelHi: 'सफलता व प्रमाण',
    taglineEn: 'Verifiable Ground Achievements, Beneficiary Stories & Evidence',
    taglineHi: 'जमीनी उपलब्धियां, लाभार्थियों के अनुभव और प्रमाणित साक्ष्य',
    category: 'vision',
    hash: 'impact-proof',
    aliases: ['impact-proof', 'impact-stories', 'proof', 'achievements'],
  },
  'roadmap-2027': {
    id: 'roadmap-2027',
    labelEn: '2027 Roadmap',
    labelHi: '2027 रोडमैप',
    taglineEn: 'Phased Strategic Milestone Plan Leading to Assembly Elections 2027',
    taglineHi: 'विधानसभा चुनाव 2027 तक का चरणबद्ध रणनीतिक कार्यक्रम',
    category: 'vision',
    hash: 'roadmap-2027',
    aliases: ['roadmap-2027', 'election-roadmap', 'roadmap'],
  },
  'social-work': {
    id: 'social-work',
    labelEn: 'Social Work',
    labelHi: 'समाज सेवा',
    taglineEn: '10 Grassroots Community Service Domains Across Kasganj',
    taglineHi: 'कासगंज में 10 प्रमुख क्षेत्रों में निरंतर जनसेवा कार्य',
    category: 'service',
    hash: 'social-work',
    aliases: ['social-work', 'social-service', 'seva'],
  },
  'public-issues': {
    id: 'public-issues',
    labelEn: 'Public Issues',
    labelHi: 'जनमुद्दे',
    taglineEn: '11 Local Issues in Kasganj, Citizen Grievance Portal & Petitions',
    taglineHi: 'कासगंज की 11 बुनियादी समस्याएं, जन-शिकायत निवारण एवं समाधान',
    category: 'vision',
    hash: 'public-issues',
    aliases: ['public-issues', 'issues', 'grievance', 'samasya'],
  },
  newsletter: {
    id: 'newsletter',
    labelEn: 'Weekly Newsletter',
    labelHi: 'साप्ताहिक बुलेटिन',
    taglineEn: 'Kasganj Samvad - Direct Weekly Updates from the Ground',
    taglineHi: 'कासगंज संवाद - जमीन से जुड़े साप्ताहिक समाचार और विचार',
    category: 'engage',
    hash: 'newsletter',
    aliases: ['newsletter', 'community-newsletter', 'kasganj-samvad'],
  },
  volunteer: {
    id: 'volunteer',
    labelEn: 'Join as Volunteer',
    labelHi: 'स्वयंसेवक बनें',
    taglineEn: 'Become a Changemaker in Kasganj - Join the Grassroots Brigade',
    taglineHi: 'कासगंज के नवनिर्माण में भागीदार बनें - हमारे स्वयंसेवक दल से जुड़ें',
    category: 'engage',
    hash: 'volunteer',
    aliases: ['volunteer', 'volunteer-registration', 'join'],
  },
  initiatives: {
    id: 'initiatives',
    labelEn: 'Key Initiatives',
    labelHi: 'प्रमुख पहल',
    taglineEn: 'Flagship Programs: Education Rath, Health Outreach, Youth Career',
    taglineHi: 'प्रमुख कार्यक्रम: शिक्षा रथ, स्वास्थ्य शिविर, युवा करियर मार्गदर्शन',
    category: 'service',
    hash: 'initiatives',
    aliases: ['initiatives', 'programs', 'projects'],
  },
  'campaign-fund': {
    id: 'campaign-fund',
    labelEn: 'Campaign Fund (UPI)',
    labelHi: 'चुनावी जनसहयोग (UPI)',
    taglineEn: '100% Transparent Grassroots Crowdfunding via PhonePe/GPay UPI QR',
    taglineHi: 'शत-प्रतिशत पारदर्शी जनसहयोग - यूपीआई क्यूआर कोड के माध्यम से',
    category: 'engage',
    hash: 'campaign-fund',
    aliases: ['campaign-fund', 'donation', 'contribute', 'fund'],
  },
  'ambedkar-trust': {
    id: 'ambedkar-trust',
    labelEn: 'Dr. Ambedkar Trust',
    labelHi: 'डॉ. आंबेडकर ट्रस्ट',
    taglineEn: 'Dr. Ambedkar Gramin Vikas Trust - Education, Libraries & Equality',
    taglineHi: 'डॉ. आंबेडकर ग्रामीण विकास ट्रस्ट - शिक्षा, पुस्तकालय और समता',
    category: 'service',
    hash: 'ambedkar-trust',
    aliases: ['ambedkar-trust', 'trust', 'ambedkar'],
  },
  experience: {
    id: 'experience',
    labelEn: 'Experience',
    labelHi: 'कार्य अनुभव',
    taglineEn: 'Professional Leadership, Institutional Management & Public Service',
    taglineHi: 'पेशेवर कार्य अनुभव, संगठनात्मक प्रबंधन एवं जनसेवा पृष्ठभूमि',
    category: 'core',
    hash: 'experience',
    aliases: ['experience', 'work-experience', 'career'],
  },
  'education-skills': {
    id: 'education-skills',
    labelEn: 'Education & Skills',
    labelHi: 'शिक्षा व योग्यता',
    taglineEn: 'Academic Degrees, Analytical Aptitude & AI Career Advisor',
    taglineHi: 'एम.एससी. गणित योग्यता, विश्लेषणात्मक कौशल और एआई करियर सलाहकार',
    category: 'core',
    hash: 'education-skills',
    aliases: ['education-skills', 'education', 'skills'],
  },
  gallery: {
    id: 'gallery',
    labelEn: 'Photo Gallery',
    labelHi: 'चित्र दीर्घा',
    taglineEn: 'High-Resolution Photographic Documentation of Public Life & Field Work',
    taglineHi: 'सार्वजनिक जीवन, जनसंवाद और जमीनी सेवा का प्रमाणित चित्र संग्रह',
    category: 'media',
    hash: 'gallery',
    aliases: ['gallery', 'photos', 'photo-gallery'],
  },
  'speeches-videos': {
    id: 'speeches-videos',
    labelEn: 'Speeches & Videos',
    labelHi: 'भाषण एवं वीडियो',
    taglineEn: 'Official Speeches, Public Addresses, Interviews & Audio Records',
    taglineHi: 'आधिकारिक भाषण, जनसंवाद वक्तव्य, साक्षात्कार और वीडियो संग्रह',
    category: 'media',
    hash: 'speeches-videos',
    aliases: ['speeches-videos', 'videos', 'speeches'],
  },
  'media-updates': {
    id: 'media-updates',
    labelEn: 'Media & Updates',
    labelHi: 'मीडिया एवं समाचार',
    taglineEn: 'Press Coverage, Newspaper Clippings & Official Press Releases',
    taglineHi: 'अखबारों में प्रकाशित समाचार, प्रेस विज्ञप्ति और आधिकारिक बयान',
    category: 'media',
    hash: 'media-updates',
    aliases: ['media-updates', 'media', 'press', 'news'],
  },
  'social-media': {
    id: 'social-media',
    labelEn: 'Social Media',
    labelHi: 'सोशल मीडिया',
    taglineEn: 'Official Channels on X, Facebook, YouTube, Instagram & WhatsApp',
    taglineHi: 'फेसबुक, एक्स, यूट्यूब, इंस्टाग्राम और व्हाट्सएप के आधिकारिक चैनल',
    category: 'media',
    hash: 'social-media',
    aliases: ['social-media', 'social', 'channels'],
  },
  contact: {
    id: 'contact',
    labelEn: 'Contact',
    labelHi: 'संपर्क',
    taglineEn: 'Kasganj Office Address, Direct Helpline, Janata Darbar & Inquiry Form',
    taglineHi: 'कासगंज कार्यालय पता, सीधी हेल्पलाइन, जनता दरबार और संपर्क प्रपत्र',
    category: 'engage',
    hash: 'contact',
    aliases: ['contact', 'office', 'helpline', 'reach-us'],
  },
  'photo-studio': {
    id: 'photo-studio',
    labelEn: 'Photo Studio',
    labelHi: 'फोटो स्टूडियो',
    taglineEn: 'Select, Resize, Zoom, Crop & Apply Official Photos Across Portfolio Slots',
    taglineHi: 'फोटो चयन, आकार निर्धारण, जूम, फ्रेम और पोर्टफोलियो में लाइव लागू करें',
    category: 'tools',
    hash: 'photo-studio',
    aliases: ['photo-studio', 'photo-s', 'photos', 'studio', 'photo-adjuster'],
  },
};

export const resolvePageFromHash = (hash: string): PageId => {
  const cleanHash = hash.replace(/^#\/?/, '').trim().toLowerCase();
  if (!cleanHash) return 'home';

  for (const page of Object.values(PAGE_CONFIG)) {
    if (page.id === cleanHash || page.hash === cleanHash || page.aliases.includes(cleanHash)) {
      return page.id;
    }
  }

  return 'home';
};
