import React, { useState } from 'react';
import {
  Menu,
  X,
  Globe,
  ChevronDown,
  Bot,
  Sliders,
  Image as ImageIcon,
  Home,
  User,
  Flag,
  Calendar,
  Heart,
  HelpCircle,
  Mail,
  Users,
  Award,
  QrCode,
  ShieldCheck,
  Briefcase,
  GraduationCap,
  Video,
  FileText,
  Share2,
  PhoneCall,
  Sparkles,
} from 'lucide-react';
import { Language } from '../types';
import { PageId, PAGE_CONFIG } from '../data/pageConfig';

interface HeaderProps {
  lang: Language;
  activePage: PageId;
  onNavigate: (page: PageId) => void;
  onToggleLang: () => void;
  onOpenAiChat: () => void;
  onOpenPhotoStudio?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  activePage,
  onNavigate,
  onToggleLang,
  onOpenAiChat,
  onOpenPhotoStudio,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);

  const mainNavItems: { id: PageId; icon: any }[] = [
    { id: 'home', icon: Home },
    { id: 'about', icon: User },
    { id: 'public-role', icon: Award },
    { id: 'vision-2027', icon: Flag },
    { id: 'initiatives', icon: Sparkles },
    { id: 'gallery', icon: ImageIcon },
    { id: 'contact', icon: PhoneCall },
  ];

  const pageGroups: {
    groupNameEn: string;
    groupNameHi: string;
    items: { id: PageId; icon: any }[];
  }[] = [
    {
      groupNameEn: 'Profile & Background',
      groupNameHi: 'परिचय व पृष्ठभूमि',
      items: [
        { id: 'about', icon: User },
        { id: 'public-role', icon: Award },
        { id: 'experience', icon: Briefcase },
        { id: 'education-skills', icon: GraduationCap },
      ],
    },
    {
      groupNameEn: 'Vision & Mission 2027',
      groupNameHi: 'कासगंज विजन 2027',
      items: [
        { id: 'vision-2027', icon: Flag },
        { id: 'roadmap-2027', icon: Calendar },
        { id: 'impact-proof', icon: ShieldCheck },
        { id: 'public-issues', icon: HelpCircle },
      ],
    },
    {
      groupNameEn: 'Social Service & Foundation',
      groupNameHi: 'समाज सेवा व ट्रस्ट',
      items: [
        { id: 'initiatives', icon: Sparkles },
        { id: 'social-work', icon: Heart },
        { id: 'ambedkar-trust', icon: ShieldCheck },
        { id: 'newsletter', icon: Mail },
      ],
    },
    {
      groupNameEn: 'Media & Photo Studio',
      groupNameHi: 'मीडिया व फोटो स्टूडियो',
      items: [
        { id: 'gallery', icon: ImageIcon },
        { id: 'speeches-videos', icon: Video },
        { id: 'media-updates', icon: FileText },
        { id: 'social-media', icon: Share2 },
        { id: 'photo-studio', icon: Sliders },
      ],
    },
    {
      groupNameEn: 'Get Involved & Support',
      groupNameHi: 'सहयोग व संपर्क',
      items: [
        { id: 'volunteer', icon: Users },
        { id: 'campaign-fund', icon: QrCode },
        { id: 'contact', icon: PhoneCall },
      ],
    },
  ];

  const handleNavClick = (pageId: PageId) => {
    onNavigate(pageId);
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-200/80 transition-all shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Zone 1: Wordmark with Portrait Thumbnail */}
        <button
          onClick={() => handleNavClick('home')}
          className="flex items-center gap-2.5 text-lg sm:text-xl font-bold font-display text-slate-900 tracking-tight hover:text-blue-900 transition-colors whitespace-nowrap group text-left cursor-pointer"
        >
          <div className="w-8 h-8 rounded-full overflow-hidden border-2 border-amber-500/80 shadow-xs bg-slate-900 shrink-0 flex items-center justify-center">
            <img
              src="/nb.jpeg"
              alt="Praveen Kumar Mishra"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
              className="w-full h-full object-cover"
              style={{ objectPosition: '50% 20%' }}
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col">
            <span className="leading-tight font-extrabold text-slate-900 group-hover:text-blue-900">
              {lang === 'hi' ? 'प्रवीण कुमार मिश्र' : 'Praveen Kumar Mishra'}
            </span>
            <span className="text-[10px] text-amber-600 font-semibold uppercase tracking-wider">
              {lang === 'hi' ? '100 - कासगंज (उ.प्र.)' : '100 - Kasganj (U.P.)'}
            </span>
          </div>
        </button>

        {/* Zone 2: Desktop Navigation Bar with Categorized Dropdown */}
        <nav className="hidden xl:flex items-center gap-5 text-sm font-semibold text-slate-600">
          {mainNavItems.map((item) => {
            const meta = PAGE_CONFIG[item.id];
            const isActive = activePage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`py-1.5 px-2 rounded-lg transition-all cursor-pointer whitespace-nowrap text-xs sm:text-sm font-medium ${
                  isActive
                    ? 'text-blue-950 font-bold border-b-2 border-amber-500 bg-amber-50/50'
                    : 'hover:text-blue-900 hover:bg-slate-50 text-slate-700'
                }`}
              >
                {lang === 'hi' ? meta.labelHi : meta.labelEn}
              </button>
            );
          })}

          {/* Categorized "All Pages" Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-lg text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer border ${
                moreDropdownOpen
                  ? 'bg-blue-950 text-white border-blue-950'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-800 border-slate-300'
              }`}
              aria-expanded={moreDropdownOpen}
            >
              <span>{lang === 'hi' ? 'सभी पृष्ठ (20)' : 'All Pages (20)'}</span>
              <ChevronDown className={`w-3.5 h-3.5 transition-transform ${moreDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {moreDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setMoreDropdownOpen(false)}
                />
                <div className="absolute top-full right-0 mt-2 w-[720px] bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 z-50 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                      {lang === 'hi' ? 'सभी 20 समर्पित पृष्ठ' : 'Explore All 20 Dedicated Pages'}
                    </span>
                    <button
                      onClick={() => setMoreDropdownOpen(false)}
                      className="text-slate-400 hover:text-slate-600 text-xs cursor-pointer"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-6">
                    {pageGroups.map((group) => (
                      <div key={group.groupNameEn} className="space-y-2">
                        <h4 className="text-[11px] font-bold uppercase tracking-wider text-amber-700 pb-1 border-b border-amber-100">
                          {lang === 'hi' ? group.groupNameHi : group.groupNameEn}
                        </h4>
                        <div className="space-y-1">
                          {group.items.map((item) => {
                            const meta = PAGE_CONFIG[item.id];
                            const Icon = item.icon;
                            const isActive = activePage === item.id;
                            return (
                              <button
                                key={item.id}
                                onClick={() => handleNavClick(item.id)}
                                className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs flex items-center gap-2 transition-colors cursor-pointer ${
                                  isActive
                                    ? 'bg-amber-100 text-amber-900 font-bold'
                                    : 'text-slate-700 hover:bg-slate-50 hover:text-blue-900'
                                }`}
                              >
                                <Icon className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                                <span className="truncate">
                                  {lang === 'hi' ? meta.labelHi : meta.labelEn}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
        </nav>

        {/* Zone 3: Actions & Photo Studio Button */}
        <div className="flex items-center gap-2">
          {/* Photo Studio / Photo S Button (Dedicated Page Navigation) */}
          <button
            onClick={() => handleNavClick('photo-studio')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shadow-xs ${
              activePage === 'photo-studio'
                ? 'bg-amber-500 text-slate-950 ring-2 ring-amber-300'
                : 'text-amber-900 bg-amber-100 hover:bg-amber-200 border border-amber-300/80'
            }`}
            title="फोटो स्टूडियो (Photo S) / Photo Studio & Sizer"
          >
            <Sliders className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden sm:inline">
              {lang === 'hi' ? 'फोटो स्टूडियो' : 'Photo Studio'}
            </span>
            <span className="sm:hidden font-mono font-bold">Photo S</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-700 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
            title="Switch Language / भाषा बदलें"
          >
            <Globe className="w-3.5 h-3.5 text-amber-600" />
            <span>{lang === 'en' ? 'हिंदी' : 'EN'}</span>
          </button>

          {/* Praveen AI Button */}
          <button
            onClick={onOpenAiChat}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-white bg-gradient-to-r from-blue-900 to-indigo-950 hover:from-blue-800 hover:to-indigo-900 rounded-lg transition-all whitespace-nowrap shadow-xs cursor-pointer border border-blue-400/30"
            title="Chat with Praveen AI / एआई जनसंवाद"
          >
            <Bot className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'hi' ? 'एआई जनसंवाद' : 'Praveen AI'}</span>
          </button>

          {/* Mobile Menu Toggle Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="xl:hidden p-2 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 max-h-[85vh] overflow-y-auto shadow-2xl animate-in slide-in-from-top-4 duration-200">
          {/* Quick Action Strip */}
          <div className="grid grid-cols-2 gap-2 pb-4 border-b border-slate-100">
            <button
              onClick={() => handleNavClick('photo-studio')}
              className="p-2.5 rounded-xl bg-amber-100 text-amber-900 font-bold text-xs flex items-center justify-center gap-2 border border-amber-300/80 cursor-pointer"
            >
              <Sliders className="w-4 h-4 text-amber-600" />
              <span>{lang === 'hi' ? 'फोटो स्टूडियो' : 'Photo Studio'}</span>
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAiChat();
              }}
              className="p-2.5 rounded-xl bg-blue-950 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer"
            >
              <Bot className="w-4 h-4 text-amber-400" />
              <span>{lang === 'hi' ? 'एआई जनसंवाद' : 'Praveen AI'}</span>
            </button>
          </div>

          {/* Grouped links for mobile */}
          <div className="space-y-4 pt-4">
            <button
              onClick={() => handleNavClick('home')}
              className={`w-full text-left px-3 py-2.5 rounded-xl text-sm font-bold flex items-center gap-2.5 transition-colors ${
                activePage === 'home'
                  ? 'bg-amber-500 text-slate-950'
                  : 'bg-slate-50 text-slate-800 hover:bg-slate-100'
              }`}
            >
              <Home className="w-4 h-4" />
              <span>{lang === 'hi' ? 'मुख्य पृष्ठ (Homepage)' : 'Home Page'}</span>
            </button>

            {pageGroups.map((group) => (
              <div key={group.groupNameEn} className="space-y-1">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block px-1">
                  {lang === 'hi' ? group.groupNameHi : group.groupNameEn}
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1">
                  {group.items.map((item) => {
                    const meta = PAGE_CONFIG[item.id];
                    const Icon = item.icon;
                    const isActive = activePage === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleNavClick(item.id)}
                        className={`w-full text-left px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-2.5 transition-colors ${
                          isActive
                            ? 'bg-amber-100 text-amber-950 font-bold border border-amber-300'
                            : 'text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                        <span className="truncate">
                          {lang === 'hi' ? meta.labelHi : meta.labelEn}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
