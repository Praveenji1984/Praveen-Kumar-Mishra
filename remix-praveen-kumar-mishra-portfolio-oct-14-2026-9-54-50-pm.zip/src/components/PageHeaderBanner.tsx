import React from 'react';
import { Home, ChevronRight, ArrowLeft } from 'lucide-react';
import { Language } from '../types';
import { PAGE_CONFIG, PageId } from '../data/pageConfig';

interface PageHeaderBannerProps {
  pageId: PageId;
  lang: Language;
  onNavigate: (page: PageId) => void;
}

export const PageHeaderBanner: React.FC<PageHeaderBannerProps> = ({
  pageId,
  lang,
  onNavigate,
}) => {
  const meta = PAGE_CONFIG[pageId];
  if (!meta || pageId === 'home') return null;

  return (
    <div className="bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white border-b border-amber-500/30 py-8 sm:py-10 shadow-inner">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center gap-2 text-xs text-slate-300 mb-4 flex-wrap">
          <button
            onClick={() => onNavigate('home')}
            className="flex items-center gap-1 hover:text-amber-400 transition-colors cursor-pointer"
          >
            <Home className="w-3.5 h-3.5 text-amber-500" />
            <span>{lang === 'hi' ? 'मुख्य पृष्ठ' : 'Home'}</span>
          </button>
          <ChevronRight className="w-3 h-3 text-slate-500" />
          <span className="font-semibold text-amber-400">
            {lang === 'hi' ? meta.labelHi : meta.labelEn}
          </span>
        </nav>

        {/* Page Title & Back CTA */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-[11px] font-semibold text-amber-400 uppercase tracking-widest mb-2">
              <span>{lang === 'hi' ? 'समर्पित पृष्ठ' : 'Official Page'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-display tracking-tight text-white">
              {lang === 'hi' ? meta.labelHi : meta.labelEn}
            </h1>
            <p className="mt-1.5 text-xs sm:text-sm text-slate-300 max-w-2xl font-medium">
              {lang === 'hi' ? meta.taglineHi : meta.taglineEn}
            </p>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={() => onNavigate('home')}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-semibold text-white transition-all cursor-pointer shadow-xs"
            >
              <ArrowLeft className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'hi' ? 'मुख्य पृष्ठ पर वापस' : 'Back to Home'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
