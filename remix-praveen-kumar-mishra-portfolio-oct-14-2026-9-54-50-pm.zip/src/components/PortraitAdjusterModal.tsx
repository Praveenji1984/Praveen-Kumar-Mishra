import React, { useState, useEffect, useRef } from 'react';
import {
  Sliders,
  Upload,
  Check,
  RotateCcw,
  Sparkles,
  Crop,
  ZoomIn,
  Move,
  Save,
  X,
  Image as ImageIcon,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';
import { Language } from '../types';

export interface PhotoSettings {
  imageUrl: string;
  zoom: number; // 80 to 160%
  positionX: number; // 0 to 100%
  positionY: number; // 0 to 100%
  aspectRatio: '3/4' | '4/5' | '1/1' | '2/3';
  shape: 'rounded' | 'circle' | 'card';
  showGoldBorder: boolean;
}

export const DEFAULT_PHOTO_SETTINGS: PhotoSettings = {
  imageUrl: '/nb.jpeg',
  zoom: 105,
  positionX: 50,
  positionY: 20, // Focus slightly toward upper chest and face
  aspectRatio: '3/4',
  shape: 'rounded',
  showGoldBorder: true,
};

interface PortraitAdjusterModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onSettingsSaved: (settings: PhotoSettings) => void;
  currentSettings: PhotoSettings;
}

export const PortraitAdjusterModal: React.FC<PortraitAdjusterModalProps> = ({
  isOpen,
  onClose,
  lang,
  onSettingsSaved,
  currentSettings,
}) => {
  const [settings, setSettings] = useState<PhotoSettings>(currentSettings);
  const [previewError, setPreviewError] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setSettings(currentSettings);
  }, [currentSettings, isOpen]);

  if (!isOpen) return null;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();

    reader.onload = async () => {
      const base64 = reader.result as string;

      // Update locally
      setSettings((prev) => ({
        ...prev,
        imageUrl: base64,
      }));
      setPreviewError(false);

      // Attempt to save to backend /public/nb.jpeg as well
      try {
        await fetch('/api/upload-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64,
            filename: file.name.endsWith('.jpeg') || file.name.endsWith('.jpg') ? file.name : 'nb.jpeg',
          }),
        });
      } catch (err) {
        console.warn('Backend photo upload optional fallback:', err);
      } finally {
        setIsUploading(false);
      }
    };

    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    localStorage.setItem('praveen_portrait_settings', JSON.stringify(settings));
    if (settings.imageUrl) {
      localStorage.setItem('praveen_portrait_url', settings.imageUrl);
    }
    onSettingsSaved(settings);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  const handleReset = () => {
    setSettings(DEFAULT_PHOTO_SETTINGS);
    setPreviewError(false);
  };

  const getAspectRatioClass = () => {
    switch (settings.aspectRatio) {
      case '1/1':
        return 'aspect-square';
      case '4/5':
        return 'aspect-4/5';
      case '2/3':
        return 'aspect-2/3';
      case '3/4':
      default:
        return 'aspect-3/4';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200 overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl relative my-8 text-white">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold shadow-xs">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-bold font-display text-white">
                {lang === 'hi' ? 'फोटो आकार एवं फ्रेम समायोजन' : 'Adjust Photo Size & Framing'}
              </h3>
              <p className="text-xs text-slate-400">
                {lang === 'hi'
                  ? 'अपनी फोटो (nb.jpeg) का आकार, जूम, फ्रेम और संरेखण सेट करें'
                  : 'Customize zoom scale, vertical position, aspect ratio, and framing'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Grid: Left Controls (6 cols), Right Live Preview (6 cols) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
          {/* Controls Column */}
          <div className="md:col-span-7 space-y-5">
            {/* File Upload / Replace action */}
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-300">
                  {lang === 'hi' ? 'फोटो फ़ाइल चयन:' : 'Select Photo File:'}
                </span>
                <span className="text-[11px] text-amber-400 font-mono">nb.jpeg</span>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-900/60 hover:bg-blue-800 border border-blue-500/40 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-colors shadow-xs"
              >
                <Upload className="w-4 h-4 text-amber-400" />
                <span>
                  {isUploading
                    ? lang === 'hi'
                      ? 'फोटो लोड हो रही है...'
                      : 'Uploading Photo...'
                    : lang === 'hi'
                    ? 'कंप्यूटर/मोबाइल से nb.jpeg चुनें'
                    : 'Choose nb.jpeg from Device'}
                </span>
              </button>
            </div>

            {/* Slider 1: Zoom / Scale */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-bold text-slate-300 flex items-center gap-1.5">
                  <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'hi' ? 'जूम / आकार (Size Scale)' : 'Size / Zoom Scale'}</span>
                </label>
                <span className="font-mono text-amber-300 font-bold">{settings.zoom}%</span>
              </div>
              <input
                type="range"
                min="80"
                max="160"
                step="2"
                value={settings.zoom}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, zoom: Number(e.target.value) }))
                }
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>80% (छोटा/दूर)</span>
                <span>100% (सामान्य)</span>
                <span>160% (क्लोज-अप)</span>
              </div>
            </div>

            {/* Slider 2: Vertical Position (Y Axis) */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-bold text-slate-300 flex items-center gap-1.5">
                  <Move className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'hi' ? 'ऊर्ध्वाधर स्थिति (Vertical Focus)' : 'Vertical Focus (Y-Axis)'}</span>
                </label>
                <span className="font-mono text-amber-300 font-bold">{settings.positionY}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="2"
                value={settings.positionY}
                onChange={(e) =>
                  setSettings((prev) => ({ ...prev, positionY: Number(e.target.value) }))
                }
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0% (शीर्ष / चेहरा)</span>
                <span>50% (मध्य)</span>
                <span>100% (निचला हिस्सा)</span>
              </div>
            </div>

            {/* Aspect Ratio Selector */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Crop className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'hi' ? 'फ्रेम अनुपात (Aspect Ratio):' : 'Aspect Ratio:'}</span>
              </label>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { id: '3/4', label: '3:4 (Portrait)' },
                  { id: '4/5', label: '4:5 (Classic)' },
                  { id: '1/1', label: '1:1 (Square)' },
                  { id: '2/3', label: '2:3 (Tall)' },
                ].map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() =>
                      setSettings((prev) => ({ ...prev, aspectRatio: item.id as any }))
                    }
                    className={`py-2 px-1 text-center rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                      settings.aspectRatio === item.id
                        ? 'bg-amber-400 text-slate-950 border-amber-400'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Shape & Framing Style */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">
                {lang === 'hi' ? 'फ्रेम शैली (Shape Style):' : 'Frame Shape & Border:'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, shape: 'rounded' }))}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    settings.shape === 'rounded'
                      ? 'bg-blue-900 border-amber-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {lang === 'hi' ? 'आधुनिक कार्ड (Rounded-2xl)' : 'Modern Card'}
                </button>
                <button
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, shape: 'circle' }))}
                  className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    settings.shape === 'circle'
                      ? 'bg-blue-900 border-amber-400 text-white'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {lang === 'hi' ? 'गोल पदक (Circular Medal)' : 'Circular Medal'}
                </button>
              </div>
            </div>

            {/* Gold Border Toggle */}
            <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950/60 border border-slate-800">
              <span className="text-xs font-semibold text-slate-300">
                {lang === 'hi' ? 'स्वर्णिम बॉर्डर व चमक (Gold Rim Accent)' : 'Gold Rim Accent Border'}
              </span>
              <button
                type="button"
                onClick={() =>
                  setSettings((prev) => ({ ...prev, showGoldBorder: !prev.showGoldBorder }))
                }
                className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                  settings.showGoldBorder ? 'bg-amber-400' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`absolute top-1 w-4 h-4 rounded-full bg-slate-950 transition-all ${
                    settings.showGoldBorder ? 'left-7' : 'left-1'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Right Column: Live Interactive Preview */}
          <div className="md:col-span-5 flex flex-col items-center">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              {lang === 'hi' ? 'लाइव पूर्वावलोकन (Live Preview)' : 'Live Preview'}
            </span>

            {/* Preview Frame Container */}
            <div
              className={`w-full max-w-xs relative overflow-hidden bg-slate-950 shadow-2xl transition-all ${getAspectRatioClass()} ${
                settings.shape === 'circle' ? 'rounded-full' : 'rounded-2xl'
              } ${
                settings.showGoldBorder
                  ? 'border-2 border-amber-400/80 shadow-amber-400/20'
                  : 'border border-slate-700'
              }`}
            >
              {/* The Image with Live Transforms */}
              <img
                src={settings.imageUrl}
                alt="Praveen Kumar Mishra"
                onError={() => setPreviewError(true)}
                className="w-full h-full object-cover transition-transform duration-150"
                style={{
                  transform: `scale(${settings.zoom / 100})`,
                  objectPosition: `${settings.positionX}% ${settings.positionY}%`,
                }}
                referrerPolicy="no-referrer"
              />

              {previewError && (
                <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-4 text-center text-xs text-amber-200">
                  <ImageIcon className="w-8 h-8 text-amber-400 mb-2" />
                  <span>
                    {lang === 'hi'
                      ? 'कृपया ऊपर "nb.jpeg चुनें" बटन पर क्लिक करके अपनी फोटो लोड करें।'
                      : 'Please click "Choose nb.jpeg" above to load your photo.'}
                  </span>
                </div>
              )}
            </div>

            <p className="text-[11px] text-slate-400 text-center mt-3">
              {lang === 'hi'
                ? 'यह आकार वेबसाइट के मुख्य पृष्ठ (Hero) व परिचय पर स्वतः लागू होगा।'
                : 'This framing will automatically apply to the Hero and About sections.'}
            </p>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="mt-8 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleReset}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'डिफ़ॉल्ट रीसेट करें' : 'Reset to Default'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs cursor-pointer transition-colors"
            >
              {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-md cursor-pointer transition-all"
            >
              {savedSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-800" />
                  <span>{lang === 'hi' ? 'सफलतापूर्वक सहेजा गया!' : 'Settings Saved!'}</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'फोटो व आकार लागू करें' : 'Apply & Save Settings'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
