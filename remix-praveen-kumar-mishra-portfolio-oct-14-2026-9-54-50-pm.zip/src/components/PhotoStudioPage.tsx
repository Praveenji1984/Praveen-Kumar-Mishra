import React, { useState, useEffect, useRef } from 'react';
import {
  Sliders,
  Upload,
  Crop,
  ZoomIn,
  Move,
  Save,
  Image as ImageIcon,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Layers,
  Award,
  Users,
  Megaphone,
  Briefcase,
  Flag,
  Palette,
  Eye,
  Info,
} from 'lucide-react';
import { Language, PhotoSettings } from '../types';
import { PHOTO_PRESETS, PhotoPresetItem } from '../data/photoPresets';

interface PhotoStudioPageProps {
  lang: Language;
}

export const PhotoStudioPage: React.FC<PhotoStudioPageProps> = ({ lang }) => {
  const [selectedSlot, setSelectedSlot] = useState<string>('hero');
  const [activeTab, setActiveTab] = useState<'presets' | 'upload'>('presets');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('preset-hero-c7bar');

  // Photo settings
  const [settings, setSettings] = useState<PhotoSettings>({
    imageUrl: `/${PHOTO_PRESETS[0].filename}`,
    zoom: 105,
    positionX: 50,
    positionY: 25,
    aspectRatio: '3/4',
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'gold',
    captionHi: 'कासगंज के विकास और लोगों की सेवा ही मेरा उद्देश्य है।',
    captionEn: 'Development of Kasganj and service of the people is my sole purpose.',
  });

  const [customFileLoaded, setCustomFileLoaded] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load existing settings when slot changes
  useEffect(() => {
    try {
      const storageKey =
        selectedSlot === 'hero' ? 'praveen_custom_photo_settings' : `praveen_slot_${selectedSlot}`;
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        const parsed = JSON.parse(saved);
        setSettings(parsed);
        const match = PHOTO_PRESETS.find((p) => `/${p.filename}` === parsed.imageUrl || p.svgDataUri === parsed.imageUrl);
        if (match) {
          setSelectedPresetId(match.id);
        }
      } else {
        const defaultPreset =
          PHOTO_PRESETS.find((p) => p.slot === selectedSlot) || PHOTO_PRESETS[0];
        setSelectedPresetId(defaultPreset.id);
        setSettings({
          imageUrl: `/${defaultPreset.filename}`,
          zoom: defaultPreset.defaultZoom,
          positionX: defaultPreset.defaultPositionX,
          positionY: defaultPreset.defaultPositionY,
          aspectRatio: defaultPreset.defaultAspectRatio,
          shape: defaultPreset.shape,
          showGoldBorder: defaultPreset.showGoldBorder,
          borderStyle: defaultPreset.borderStyle,
          captionHi: defaultPreset.quoteHi,
          captionEn: defaultPreset.quoteEn,
        });
      }
    } catch {
      // ignore
    }
  }, [selectedSlot]);

  // Handle Preset Selection
  const handleSelectPreset = (preset: PhotoPresetItem) => {
    setSelectedPresetId(preset.id);
    setSettings((prev) => ({
      ...prev,
      imageUrl: `/${preset.filename}`,
      zoom: preset.defaultZoom,
      positionX: preset.defaultPositionX,
      positionY: preset.defaultPositionY,
      aspectRatio: preset.defaultAspectRatio,
      borderStyle: preset.borderStyle,
      captionHi: preset.quoteHi || prev.captionHi,
      captionEn: preset.quoteEn || prev.captionEn,
    }));
    setCustomFileLoaded(true);
    setSavedSuccess(false);
  };

  // Handle File Upload from device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert(lang === 'hi' ? 'कृपया केवल छवि (Image) फ़ाइल चुनें।' : 'Please select an image file only.');
      return;
    }

    setIsUploading(true);
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      const dataUrl = uploadEvent.target?.result as string;
      setSettings((prev) => ({
        ...prev,
        imageUrl: dataUrl,
      }));
      setCustomFileLoaded(true);
      setIsUploading(false);
      setSavedSuccess(false);
    };
    reader.onerror = () => {
      setIsUploading(false);
      alert(lang === 'hi' ? 'फ़ाइल पढ़ने में त्रुटि हुई।' : 'Error reading image file.');
    };
    reader.readAsDataURL(file);
  };

  // Save changes to persistent storage & server
  const handleSave = async () => {
    try {
      const storageKey =
        selectedSlot === 'hero' ? 'praveen_custom_photo_settings' : `praveen_slot_${selectedSlot}`;
      localStorage.setItem(storageKey, JSON.stringify(settings));

      // Attempt backend persistence
      if (settings.imageUrl.startsWith('data:')) {
        await fetch('/api/upload-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageData: settings.imageUrl,
            filename: `custom-slot-${selectedSlot}-${Date.now()}.png`,
            slot: selectedSlot,
            settings,
          }),
        }).catch(() => {});
      }

      // Dispatch global event for instant live re-render
      window.dispatchEvent(
        new CustomEvent('praveen_photo_updated', {
          detail: { slot: selectedSlot, settings },
        })
      );

      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 4000);
    } catch {
      alert(lang === 'hi' ? 'सहेजने में त्रुटि हुई।' : 'Failed to save settings.');
    }
  };

  // Reset to default
  const handleReset = () => {
    const defaultPreset = PHOTO_PRESETS[0];
    setSettings({
      imageUrl: `/${defaultPreset.filename}`,
      zoom: defaultPreset.defaultZoom,
      positionX: defaultPreset.defaultPositionX,
      positionY: defaultPreset.defaultPositionY,
      aspectRatio: defaultPreset.defaultAspectRatio,
      shape: defaultPreset.shape,
      showGoldBorder: defaultPreset.showGoldBorder,
      borderStyle: defaultPreset.borderStyle,
      captionHi: defaultPreset.quoteHi,
      captionEn: defaultPreset.quoteEn,
    });
    setSelectedPresetId(defaultPreset.id);
    setSavedSuccess(false);
  };

  const slots = [
    { id: 'hero', nameEn: 'Hero Portrait', nameHi: 'मुख्य हीरो चित्र', icon: Award },
    { id: 'presidential', nameEn: 'Presidential Meeting', nameHi: 'राष्ट्रपति महोदय से भेंट', icon: Flag },
    { id: 'youth', nameEn: 'Youth Mentorship', nameHi: 'युवा मार्गदर्शन', icon: Users },
    { id: 'rally', nameEn: 'Public Rally', nameHi: 'जनसभा / रैली', icon: Megaphone },
    { id: 'office', nameEn: 'Office & Meeting', nameHi: 'कार्यालय बैठक', icon: Briefcase },
    { id: 'gallery', nameEn: 'Gallery Featured', nameHi: 'दीर्घा मुख्य चित्र', icon: ImageIcon },
  ];

  const aspectRatios = [
    { id: '3/4', label: '3:4 Portrait' },
    { id: '4/5', label: '4:5 Social' },
    { id: '1/1', label: '1:1 Square' },
    { id: '16/9', label: '16:9 Banner' },
  ];

  return (
    <div className="py-10 bg-slate-900 text-slate-100 min-h-[calc(100vh-200px)]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        {/* Intro Card */}
        <div className="bg-slate-800/80 rounded-2xl p-6 border border-amber-500/30 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-xl">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-widest">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>{lang === 'hi' ? 'फोटो स्टूडियो एवं पोर्ट्रेट कस्टमाइजर (Photo S)' : 'Photo Studio & Sizing Manager (Photo S)'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold font-display text-white">
              {lang === 'hi' ? 'वेबसाइट के लिए अपनी पसंदीदा फोटो और आकार चुनें' : 'Select, Frame & Adjust Photos for Your Portfolio'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 max-w-2xl">
              {lang === 'hi'
                ? 'कासगंज जनजीवन और सार्वजनिक दायित्व के 7 प्रामाणिक फोटो प्रीसेट में से चुनें या अपनी स्वयं की फोटो अपलोड करें। जूम, अलाइनमेंट, फ्रेम बॉर्डर और आकार को सीधे कस्टमाइज करें।'
                : 'Choose from 7 authentic high-resolution photographic presets or upload your own device photos. Calibrate zoom, pan alignment, framing styles and instantly update the website.'}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleReset}
              className="px-3.5 py-2 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs font-semibold text-slate-200 flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{lang === 'hi' ? 'रीसेट' : 'Reset'}</span>
            </button>
            <button
              onClick={handleSave}
              className="px-5 py-2 rounded-lg bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs sm:text-sm flex items-center gap-2 shadow-lg transition-all cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{lang === 'hi' ? 'पोर्टफोलियो में लागू करें' : 'Apply to Portfolio'}</span>
            </button>
          </div>
        </div>

        {savedSuccess && (
          <div className="p-4 bg-emerald-950/80 border border-emerald-500 rounded-xl text-emerald-200 text-xs sm:text-sm flex items-center gap-3 animate-in fade-in duration-200">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span className="font-semibold">
              {lang === 'hi'
                ? `सफलतापूर्वक सहेजा गया! "${slots.find((s) => s.id === selectedSlot)?.nameHi}" स्लॉट में नई फोटो और सेटिंग्स लागू हो चुकी हैं।`
                : `Settings saved successfully! Updated photo and sizing have been applied to the "${slots.find((s) => s.id === selectedSlot)?.nameEn}" slot.`}
            </span>
          </div>
        )}

        {/* Slot Selector Tabs */}
        <div className="space-y-2">
          <label className="text-xs font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-amber-500" />
            <span>{lang === 'hi' ? '1. पोर्टफोलियो स्लॉट चुनें जहां फोटो बदलनी है' : '1. Select Portfolio Slot to Customize'}</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {slots.map((slot) => {
              const Icon = slot.icon;
              const isSelected = selectedSlot === slot.id;
              return (
                <button
                  key={slot.id}
                  onClick={() => {
                    setSelectedSlot(slot.id);
                    setSavedSuccess(false);
                  }}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col gap-1.5 ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                      : 'bg-slate-800/60 border-slate-700/80 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                  <span className="text-xs font-bold leading-tight">
                    {lang === 'hi' ? slot.nameHi : slot.nameEn}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Workspace: Left Controls vs Right Live Canvas */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Controls Column */}
          <div className="lg:col-span-7 space-y-6">
            {/* Presets vs Upload Switcher */}
            <div className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
                <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
                  {lang === 'hi' ? '2. फोटो स्रोत' : '2. Photo Source'}
                </span>
                <div className="flex rounded-lg bg-slate-900 p-1 border border-slate-700">
                  <button
                    onClick={() => setActiveTab('presets')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeTab === 'presets'
                        ? 'bg-amber-500 text-slate-950 shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? '7 प्रामाणिक प्रीसेट' : '7 Authentic Presets'}</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('upload')}
                    className={`px-3 py-1 rounded-md text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                      activeTab === 'upload'
                        ? 'bg-amber-500 text-slate-950 shadow-xs'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{lang === 'hi' ? 'डिवाइस से अपलोड' : 'Upload From Device'}</span>
                  </button>
                </div>
              </div>

              {/* Tab 1: Presets Grid */}
              {activeTab === 'presets' && (
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 pt-1">
                  {PHOTO_PRESETS.map((preset) => {
                    const isSelected = selectedPresetId === preset.id;
                    return (
                      <button
                        key={preset.id}
                        onClick={() => handleSelectPreset(preset)}
                        className={`group relative rounded-xl overflow-hidden border transition-all text-left cursor-pointer p-1.5 flex flex-col gap-1.5 ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 ring-2 ring-amber-400/50'
                            : 'bg-slate-900/60 border-slate-700 hover:border-slate-500'
                        }`}
                      >
                        <div className="w-full aspect-[4/5] rounded-lg overflow-hidden bg-slate-950 relative">
                          <img
                            src={`/${preset.filename}`}
                            alt={preset.nameEn}
                            onError={(e) => {
                              // fallback to svg data uri if static file not reachable
                              (e.target as HTMLImageElement).src = preset.svgDataUri;
                            }}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            style={{
                              objectPosition: `${preset.defaultPositionX}% ${preset.defaultPositionY}%`,
                            }}
                          />
                          {isSelected && (
                            <div className="absolute top-1.5 right-1.5 bg-amber-500 text-slate-950 rounded-full p-0.5 shadow-md">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                            </div>
                          )}
                        </div>
                        <div className="px-1 pb-1">
                          <p className="text-[11px] font-bold text-white truncate">
                            {lang === 'hi' ? preset.nameHi : preset.nameEn}
                          </p>
                          <p className="text-[10px] text-slate-400 line-clamp-1">
                            {lang === 'hi' ? preset.descriptionHi : preset.descriptionEn}
                          </p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Tab 2: Upload */}
              {activeTab === 'upload' && (
                <div className="space-y-4 pt-1">
                  <div
                    onClick={() => fileInputRef.current?.click()}
                    className="border-2 border-dashed border-slate-600 hover:border-amber-400 rounded-xl p-8 text-center cursor-pointer transition-colors bg-slate-900/50 flex flex-col items-center justify-center gap-3"
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                    <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center text-amber-400 border border-slate-700">
                      <Upload className="w-6 h-6" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-white">
                        {lang === 'hi' ? 'कंप्यूटर या मोबाइल से फोटो चुनें' : 'Choose a photo from your device'}
                      </p>
                      <p className="text-xs text-slate-400 mt-1">
                        JPG, PNG, WEBP (Max 10MB)
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Sizing, Zoom, Pan & Border Controls */}
            <div className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700 space-y-6">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                {lang === 'hi' ? '3. आकार, जूम, स्थिति व फ्रेमिंग' : '3. Sizing, Zoom, Position & Frame'}
              </span>

              {/* Zoom Control */}
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                    <span>{lang === 'hi' ? 'जूम (Zoom Level)' : 'Zoom Level'}</span>
                  </label>
                  <span className="font-mono text-amber-400 font-bold">{settings.zoom}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="180"
                  step="2"
                  value={settings.zoom}
                  onChange={(e) =>
                    setSettings((prev) => ({ ...prev, zoom: Number(e.target.value) }))
                  }
                  className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
                <div className="flex items-center gap-2 pt-1 flex-wrap">
                  {[
                    { label: '85% Wide', val: 85 },
                    { label: '100% Fit', val: 100 },
                    { label: '115% Close', val: 115 },
                    { label: '135% Focus', val: 135 },
                  ].map((btn) => (
                    <button
                      key={btn.val}
                      onClick={() => setSettings((prev) => ({ ...prev, zoom: btn.val }))}
                      className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-all cursor-pointer ${
                        settings.zoom === btn.val
                          ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Pan Horizontal & Vertical */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Move className="w-3.5 h-3.5 text-amber-400" />
                      <span>{lang === 'hi' ? 'क्षैतिज स्थिति (X Focus)' : 'Horizontal Pan (X)'}</span>
                    </label>
                    <span className="font-mono text-amber-400 font-bold">{settings.positionX}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings.positionX}
                    onChange={(e) =>
                      setSettings((prev) => ({ ...prev, positionX: Number(e.target.value) }))
                    }
                    className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                  />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Move className="w-3.5 h-3.5 text-amber-400" />
                      <span>{lang === 'hi' ? 'ऊर्ध्वाधर स्थिति (Y Focus)' : 'Vertical Pan (Y)'}</span>
                    </label>
                    <span className="font-mono text-amber-400 font-bold">{settings.positionY}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings.positionY}
                    onChange={(e) =>
                      setSettings((prev) => ({ ...prev, positionY: Number(e.target.value) }))
                    }
                    className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
                  />
                </div>
              </div>

              {/* Quick Alignment Presets */}
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] text-slate-400">
                  {lang === 'hi' ? 'त्वरित फोकस:' : 'Quick Focus:'}
                </span>
                {[
                  { label: 'Center (50/50)', x: 50, y: 50 },
                  { label: 'Face/Head (50/20)', x: 50, y: 20 },
                  { label: 'Left (30/25)', x: 30, y: 25 },
                  { label: 'Right (70/25)', x: 70, y: 25 },
                ].map((pos) => (
                  <button
                    key={pos.label}
                    onClick={() =>
                      setSettings((prev) => ({ ...prev, positionX: pos.x, positionY: pos.y }))
                    }
                    className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-[10px] font-semibold text-slate-300 hover:text-white hover:border-amber-400 transition-colors cursor-pointer"
                  >
                    {pos.label}
                  </button>
                ))}
              </div>

              {/* Aspect Ratio Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Crop className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'hi' ? 'पहलू अनुपात (Aspect Ratio)' : 'Aspect Ratio'}</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {aspectRatios.map((ratio) => (
                    <button
                      key={ratio.id}
                      onClick={() =>
                        setSettings((prev) => ({
                          ...prev,
                          aspectRatio: ratio.id as any,
                        }))
                      }
                      className={`p-2 rounded-lg border text-center text-xs font-bold transition-all cursor-pointer ${
                        settings.aspectRatio === ratio.id
                          ? 'bg-amber-500/20 border-amber-400 text-white'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {ratio.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Border & Frame Style */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <Palette className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'hi' ? 'फ्रेम एवं बॉर्डर शैली' : 'Frame & Border Style'}</span>
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[
                    { id: 'gold', nameEn: 'Royal Gold', nameHi: 'शाही सुनहरा' },
                    { id: 'navy', nameEn: 'Leadership Navy', nameHi: 'गंभीर नेवी' },
                    { id: 'tricolor', nameEn: 'Tricolor Indian', nameHi: 'तिरंगा बॉर्डर' },
                    { id: 'none', nameEn: 'Clean Borderless', nameHi: 'न्यूनतम बॉर्डर' },
                  ].map((style) => (
                    <button
                      key={style.id}
                      onClick={() =>
                        setSettings((prev) => ({
                          ...prev,
                          borderStyle: style.id as any,
                          showGoldBorder: style.id !== 'none',
                        }))
                      }
                      className={`p-2 rounded-lg border text-center text-xs font-bold transition-all cursor-pointer ${
                        settings.borderStyle === style.id
                          ? 'bg-amber-500/20 border-amber-400 text-white'
                          : 'bg-slate-900 border-slate-700 text-slate-400 hover:text-white'
                      }`}
                    >
                      {lang === 'hi' ? style.nameHi : style.nameEn}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Interactive Canvas Preview */}
          <div className="lg:col-span-5 space-y-4 lg:sticky lg:top-24">
            <div className="bg-slate-800/80 rounded-2xl p-5 border border-slate-700 shadow-xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-700/80 pb-3">
                <div className="flex items-center gap-2">
                  <Eye className="w-4 h-4 text-amber-400" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    {lang === 'hi' ? 'लाइव पूर्वावलोकन (Live Canvas)' : 'Live Canvas Preview'}
                  </span>
                </div>
                <span className="text-[11px] font-mono bg-slate-900 px-2 py-0.5 rounded text-amber-400 border border-slate-700">
                  {settings.aspectRatio} | Zoom {settings.zoom}%
                </span>
              </div>

              {/* Visual Frame */}
              <div className="w-full flex items-center justify-center p-2 bg-slate-950/80 rounded-xl border border-slate-800 overflow-hidden">
                <div
                  className={`relative w-full max-w-sm overflow-hidden transition-all duration-200 ${
                    settings.aspectRatio === '3/4'
                      ? 'aspect-[3/4]'
                      : settings.aspectRatio === '4/5'
                      ? 'aspect-[4/5]'
                      : settings.aspectRatio === '1/1'
                      ? 'aspect-square'
                      : 'aspect-video'
                  } ${
                    settings.borderStyle === 'gold'
                      ? 'border-4 border-amber-400/90 shadow-[0_0_25px_rgba(251,191,36,0.25)] rounded-2xl'
                      : settings.borderStyle === 'navy'
                      ? 'border-4 border-blue-600 shadow-lg rounded-2xl'
                      : settings.borderStyle === 'tricolor'
                      ? 'border-4 border-orange-500 shadow-lg rounded-2xl'
                      : 'border border-slate-700 rounded-xl'
                  }`}
                >
                  <img
                    src={settings.imageUrl}
                    alt="Praveen Kumar Mishra Live Preview"
                    className="w-full h-full object-cover transition-all"
                    style={{
                      transform: `scale(${settings.zoom / 100})`,
                      transformOrigin: `${settings.positionX}% ${settings.positionY}%`,
                    }}
                  />

                  {/* Gradient bottom bar with caption */}
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-900/80 to-transparent p-4 text-white">
                    <p className="text-[11px] font-bold text-amber-400 tracking-wide uppercase">
                      {slots.find((s) => s.id === selectedSlot)?.nameEn}
                    </p>
                    <p className="text-xs text-slate-200 mt-0.5 font-medium line-clamp-2">
                      {lang === 'hi' ? settings.captionHi : settings.captionEn}
                    </p>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={handleSave}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2 shadow-xl hover:shadow-amber-500/20 transition-all cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>
                    {lang === 'hi'
                      ? 'पोर्टफोलियो में फोटो व आकार लागू करें'
                      : 'Apply & Save to Portfolio'}
                  </span>
                </button>
                <p className="text-[11px] text-center text-slate-400">
                  {lang === 'hi'
                    ? 'सहेजने पर वेबसाइट के सभी संबंधित कार्ड्स तुरंत अपडेट हो जाएंगे।'
                    : 'Applying saves immediately across the website without page refresh.'}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
