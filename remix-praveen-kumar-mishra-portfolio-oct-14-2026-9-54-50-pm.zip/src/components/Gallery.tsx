import React, { useState, useEffect } from 'react';
import {
  Image as ImageIcon,
  MapPin,
  Calendar,
  Maximize2,
  X,
  Upload,
  Plus,
  Filter,
  Sliders,
  Sparkles,
  Quote,
} from 'lucide-react';
import { GALLERY_PHOTOS } from '../data/portfolioData';
import { GalleryPhoto, Language } from '../types';
import { PortraitArtwork } from './PortraitArtwork';
import { PhotoStudioModal } from './PhotoStudioModal';
import { PHOTO_PRESETS } from '../data/photoPresets';

interface GalleryProps {
  lang: Language;
}

export const Gallery: React.FC<GalleryProps> = ({ lang }) => {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [selectedPhoto, setSelectedPhoto] = useState<GalleryPhoto | null>(null);
  const [photos, setPhotos] = useState<GalleryPhoto[]>(GALLERY_PHOTOS);
  const [showAddModal, setShowAddModal] = useState(false);
  const [isStudioOpen, setIsStudioOpen] = useState(false);
  const [studioSlot, setStudioSlot] = useState<string>('gallery');
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<GalleryPhoto['category']>('social_work');
  const [newLocation, setNewLocation] = useState('Kasganj, UP');
  const [newDesc, setNewDesc] = useState('');
  const [newCustomImage, setNewCustomImage] = useState<string>('');

  // Load custom photos from localStorage if any
  useEffect(() => {
    try {
      const saved = localStorage.getItem('praveen_portfolio_custom_photos');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          setPhotos([...GALLERY_PHOTOS, ...parsed]);
        }
      }
    } catch {
      // fallback
    }
  }, []);

  const categories = [
    { id: 'all', labelEn: 'All Photos', labelHi: 'सभी चित्र' },
    { id: 'social_work', labelEn: 'Social Work', labelHi: 'समाज सेवा' },
    { id: 'community_events', labelEn: 'Community Events', labelHi: 'सामुदायिक आयोजन' },
    { id: 'public_meetings', labelEn: 'Public Meetings', labelHi: 'जनसंवाद व सभाएं' },
    { id: 'rural_development', labelEn: 'Rural Development', labelHi: 'ग्रामीण विकास' },
    { id: 'awareness', labelEn: 'Awareness Programs', labelHi: 'जागरूकता कार्यक्रम' },
    { id: 'trust_activities', labelEn: 'Trust Activities', labelHi: 'ट्रस्ट कार्य' },
    { id: 'professional', labelEn: 'Professional Life', labelHi: 'व्यावसायिक जीवन' },
  ];

  const filteredPhotos =
    activeCategory === 'all'
      ? photos
      : photos.filter((p) => p.category === activeCategory);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewCustomImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleAddPhotoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle) return;

    const newPhotoItem: GalleryPhoto = {
      id: `custom-${Date.now()}`,
      titleEn: newTitle,
      titleHi: newTitle,
      category: newCategory,
      date: 'Recent 2026',
      location: newLocation || 'Kasganj, UP',
      descriptionEn: newDesc || newTitle,
      descriptionHi: newDesc || newTitle,
      imageTheme: 'office_digital',
      accentColor: '#1e3a8a',
    };

    const updated = [newPhotoItem, ...photos];
    setPhotos(updated);

    // Save custom additions to localStorage
    try {
      const customOnly = updated.filter((p) => p.id.startsWith('custom-'));
      localStorage.setItem('praveen_portfolio_custom_photos', JSON.stringify(customOnly));
    } catch {
      // ignore storage error
    }

    setShowAddModal(false);
    setNewTitle('');
    setNewDesc('');
    setNewCustomImage('');
  };

  return (
    <section id="gallery" className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header with Add Button */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-blue-900 tracking-wider uppercase mb-2">
              <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
              <span>{lang === 'hi' ? 'चित्र दीर्घा' : 'Visual Records & Field Gallery'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold font-display text-slate-900 tracking-tight">
              {lang === 'hi' ? 'तस्वीरें एवं जनसंवाद दीर्घा' : 'Photo Gallery'}
            </h2>
            <div className="w-16 h-1 bg-amber-500 mt-3 rounded-full" />
          </div>

          {/* Header Action Buttons */}
          <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
            <button
              onClick={() => {
                setStudioSlot('gallery');
                setIsStudioOpen(true);
              }}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-400 hover:brightness-110 text-slate-950 text-xs font-bold cursor-pointer transition-all shadow-md group"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-950 group-hover:rotate-45 transition-transform" />
              <span>{lang === 'hi' ? 'चित्र चयन व आकार स्टूडियो' : 'Photo Studio & Sizer'}</span>
              <Sparkles className="w-3 h-3 text-slate-950 animate-pulse" />
            </button>

            <button
              onClick={() => setShowAddModal(true)}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-white text-xs font-semibold cursor-pointer transition-colors shadow-xs"
            >
              <Plus className="w-4 h-4 text-amber-400" />
              <span>{lang === 'hi' ? 'नया चित्र जोड़ें' : 'Add Photo'}</span>
            </button>
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-200/60 rounded-xl max-w-fit mb-8 overflow-x-auto">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                activeCategory === cat.id
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {lang === 'hi' ? cat.labelHi : cat.labelEn}
            </button>
          ))}
        </div>

        {/* Photos Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {filteredPhotos.map((photo) => {
            // Find if matching preset exists
            const matchingPreset = PHOTO_PRESETS.find(
              (p) =>
                (photo.imageUrl && photo.imageUrl.includes(p.slot)) ||
                photo.titleEn.toLowerCase().includes(p.category) ||
                photo.imageTheme.includes(p.slot)
            );
            const displayImg = matchingPreset?.svgDataUri || photo.imageUrl || '/nb.jpeg';

            return (
              <div
                key={photo.id}
                onClick={() => setSelectedPhoto(photo)}
                className="group bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-amber-400/50 transition-all cursor-pointer flex flex-col justify-between"
              >
                {/* Photo Frame Container */}
                <div className="relative h-60 bg-slate-950 overflow-hidden flex items-center justify-center">
                  <img
                    src={displayImg}
                    alt={photo.titleEn}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />

                  {/* Gradient Vignette */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-60 group-hover:opacity-30 transition-opacity" />

                  {/* Aspect Ratio Badge */}
                  {photo.aspectRatio && (
                    <div className="absolute top-3 left-3 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-xs text-[10px] font-mono text-amber-300 border border-white/10">
                      {photo.aspectRatio}
                    </div>
                  )}

                  {/* Zoom Overlay Button */}
                  <div className="absolute bottom-3 right-3 p-1.5 bg-black/70 rounded-lg text-white opacity-0 group-hover:opacity-100 transition-opacity">
                    <Maximize2 className="w-4 h-4 text-amber-400" />
                  </div>
                </div>

                {/* Caption & Metadata */}
                <div className="p-4 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mb-1">
                      <span className="font-semibold text-amber-700 uppercase">
                        {photo.category.replace('_', ' ')}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>{photo.date}</span>
                    </div>

                    <h4 className="text-sm font-bold text-slate-900 line-clamp-1 group-hover:text-blue-900 transition-colors">
                      {lang === 'hi' ? photo.titleHi : photo.titleEn}
                    </h4>

                    {/* Hindi Quote Highlight if present */}
                    {photo.quoteHi && (
                      <p className="mt-1.5 text-xs text-amber-900 font-medium italic line-clamp-2 bg-amber-50/70 p-1.5 rounded-lg border border-amber-200/50">
                        "{photo.quoteHi}"
                      </p>
                    )}

                    <p className="text-xs text-slate-500 mt-1.5 line-clamp-2">
                      {lang === 'hi' ? photo.descriptionHi : photo.descriptionEn}
                    </p>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1 truncate">
                      <MapPin className="w-3 h-3 text-amber-600 shrink-0" />
                      <span className="truncate">{photo.location}</span>
                    </span>
                    <span className="text-amber-600 font-medium shrink-0 group-hover:underline">
                      {lang === 'hi' ? 'देखें' : 'View'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Fullscreen Lightbox Modal */}
        {selectedPhoto && (
          <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5">
            <div className="relative max-w-4xl w-full bg-slate-950 rounded-2xl overflow-hidden border border-slate-800 shadow-2xl text-white">
              <button
                onClick={() => setSelectedPhoto(null)}
                className="absolute top-4 right-4 z-20 p-2 bg-black/60 hover:bg-black text-white rounded-full transition-colors cursor-pointer"
                aria-label="Close photo"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-12 max-h-[85vh] overflow-y-auto">
                <div className="md:col-span-7 bg-slate-900 flex items-center justify-center p-4 min-h-[340px]">
                  {(() => {
                    const matchingPreset = PHOTO_PRESETS.find(
                      (p) =>
                        (selectedPhoto.imageUrl && selectedPhoto.imageUrl.includes(p.slot)) ||
                        selectedPhoto.titleEn.toLowerCase().includes(p.category) ||
                        selectedPhoto.imageTheme.includes(p.slot)
                    );
                    const imgUrl = matchingPreset?.svgDataUri || selectedPhoto.imageUrl || '/nb.jpeg';
                    return (
                      <div className="w-full max-w-md rounded-xl overflow-hidden border border-slate-700 shadow-xl bg-slate-950">
                        <img
                          src={imgUrl}
                          alt={selectedPhoto.titleEn}
                          className="w-full h-auto max-h-[65vh] object-contain mx-auto"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                    );
                  })()}
                </div>

                <div className="md:col-span-5 p-6 sm:p-8 flex flex-col justify-between space-y-4">
                  <div className="space-y-3">
                    <div className="inline-block text-xs uppercase font-semibold text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-md border border-amber-400/20">
                      {selectedPhoto.category.replace('_', ' ')}
                    </div>

                    <h3 className="text-xl font-bold font-display text-white">
                      {lang === 'hi' ? selectedPhoto.titleHi : selectedPhoto.titleEn}
                    </h3>

                    <div className="flex items-center gap-3 text-xs text-slate-400 pb-2 border-b border-slate-800">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        <span>{selectedPhoto.date}</span>
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-amber-500" />
                        <span>{selectedPhoto.location}</span>
                      </span>
                    </div>

                    {/* Hindi Quote in Lightbox */}
                    {selectedPhoto.quoteHi && (
                      <div className="p-3 rounded-xl bg-slate-900 border border-amber-400/30 text-amber-200 text-xs sm:text-sm font-medium italic">
                        "{selectedPhoto.quoteHi}"
                      </div>
                    )}

                    <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {lang === 'hi' ? selectedPhoto.descriptionHi : selectedPhoto.descriptionEn}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-slate-800 space-y-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        const slot = selectedPhoto.imageTheme.includes('presidential')
                          ? 'presidential'
                          : selectedPhoto.imageTheme.includes('youth')
                          ? 'youth'
                          : selectedPhoto.imageTheme.includes('rally')
                          ? 'rally'
                          : selectedPhoto.imageTheme.includes('office')
                          ? 'office'
                          : 'hero';
                        setStudioSlot(slot);
                        setSelectedPhoto(null);
                        setIsStudioOpen(true);
                      }}
                      className="w-full py-2.5 px-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition-all shadow-md"
                    >
                      <Sliders className="w-4 h-4" />
                      <span>{lang === 'hi' ? 'इस फोटो का आकार व फ्रेम बदलें' : 'Adjust Framing in Studio'}</span>
                    </button>

                    <p className="text-[11px] text-slate-400 text-center">
                      {lang === 'hi'
                        ? 'प्रवीण कुमार मिश्र - आधिकारिक सार्वजनिक कार्य चित्र'
                        : 'Praveen Kumar Mishra - Verified Public Activity Archive'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Studio Modal Triggered from Gallery */}
        <PhotoStudioModal
          isOpen={isStudioOpen}
          onClose={() => setIsStudioOpen(false)}
          lang={lang}
          targetSlot={studioSlot as any}
        />

        {/* Add Photo Modal */}
        {showAddModal && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 relative">
              <button
                onClick={() => setShowAddModal(false)}
                className="absolute top-4 right-4 p-1 rounded-lg text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>

              <h3 className="text-lg font-bold text-slate-900 mb-1">
                {lang === 'hi' ? 'गैलरी में चित्र जोड़ें' : 'Add Photo to Gallery'}
              </h3>
              <p className="text-xs text-slate-500 mb-4">
                {lang === 'hi'
                  ? 'अपनी किसी भी सामाजिक गतिविधि का चित्र अपलोड करें या विवरण जोड़ें।'
                  : 'Add title and field documentation details to your gallery archive.'}
              </p>

              <form onSubmit={handleAddPhotoSubmit} className="space-y-3 text-xs">
                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {lang === 'hi' ? 'चित्र शीर्षक *' : 'Photo Title *'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g., Rural School Inspection"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {lang === 'hi' ? 'वर्ग (Category)' : 'Category'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  >
                    <option value="social_work">Social Work</option>
                    <option value="community_events">Community Events</option>
                    <option value="public_meetings">Public Meetings</option>
                    <option value="rural_development">Rural Development</option>
                    <option value="awareness">Awareness Programs</option>
                    <option value="trust_activities">Trust Activities</option>
                    <option value="professional">Professional Life</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {lang === 'hi' ? 'स्थान' : 'Location'}
                  </label>
                  <input
                    type="text"
                    placeholder="e.g., Kasganj, UP"
                    value={newLocation}
                    onChange={(e) => setNewLocation(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 mb-1">
                    {lang === 'hi' ? 'संक्षिप्त विवरण' : 'Description'}
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Details about this field visit..."
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300"
                  />
                </div>

                <div className="pt-2 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-3 py-1.5 bg-slate-100 rounded-lg text-slate-700"
                  >
                    {lang === 'hi' ? 'रद्द करें' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 bg-blue-950 text-white rounded-lg font-bold"
                  >
                    {lang === 'hi' ? 'जोड़ें' : 'Save Photo'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Dedicated Photo Studio & Sizer Modal */}
        <PhotoStudioModal
          isOpen={isStudioOpen}
          onClose={() => setIsStudioOpen(false)}
          lang={lang}
          targetSlot={studioSlot as any}
          onSaved={(settings) => {
            if (settings.imageUrl) {
              const newPhoto: GalleryPhoto = {
                id: `custom-studio-${Date.now()}`,
                titleEn: settings.captionEn || 'Kasganj Field Activity',
                titleHi: settings.captionHi || 'कासगंज जनसेवा गतिविधि',
                category: 'social_work',
                date: '2026 Active',
                location: 'Kasganj, UP',
                descriptionEn: settings.captionEn || 'Custom selected photo for Kasganj public service.',
                descriptionHi: settings.captionHi || 'कासगंज जनसेवा हेतु चयनित तस्वीर।',
                imageUrl: settings.imageUrl,
                aspectRatio: settings.aspectRatio,
                imageTheme: 'rally_podium',
                accentColor: '#1e3a8a',
              };
              setPhotos((prev) => [newPhoto, ...prev]);
            }
          }}
        />
      </div>
    </section>
  );
};
