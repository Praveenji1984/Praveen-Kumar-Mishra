import React from 'react';
import {
  User,
  ArrowRight,
  Award,
  BookOpen,
  Compass,
  ShieldCheck,
  CheckCircle2,
  TrendingUp,
  Heart,
  Users,
  MapPin,
  Calendar,
  Sparkles,
  Megaphone,
  QrCode,
  FileText,
  PhoneCall,
  Image as ImageIcon,
  Video,
  Send,
  Flag,
} from 'lucide-react';
import { Language } from '../types';
import { Hero } from './Hero';
import { PortraitArtwork } from './PortraitArtwork';
import { PERSONAL_INFO } from '../data/portfolioData';
import { PageId } from '../data/pageConfig';

interface HomePageProps {
  lang: Language;
  onNavigate: (page: PageId) => void;
  onOpenAiChat: () => void;
  onOpenPhotoStudio: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  lang,
  onNavigate,
  onOpenAiChat,
  onOpenPhotoStudio,
}) => {
  return (
    <div className="space-y-0">
      {/* 1. Hero Section */}
      <Hero
        lang={lang}
        onNavigate={onNavigate}
        onOpenAiChat={onOpenAiChat}
        onOpenPhotoStudio={onOpenPhotoStudio}
      />

      {/* 2. Homepage Standard "About Us" Section */}
      <section className="py-16 sm:py-24 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Left Column: Portrait & Key Badges */}
            <div className="lg:col-span-5 space-y-6">
              <div className="relative group">
                <div className="absolute -inset-2 bg-gradient-to-r from-amber-500/20 to-blue-600/20 rounded-3xl blur-xl opacity-75 group-hover:opacity-100 transition-opacity" />
                <div className="relative rounded-2xl overflow-hidden border-2 border-amber-500/40 shadow-2xl bg-slate-900">
                  <PortraitArtwork
                    type="hero"
                    className="w-full h-80 sm:h-96 object-cover"
                    alt="Praveen Kumar Mishra - Social Leader"
                  />
                  <div className="p-4 bg-slate-950/90 text-white border-t border-slate-800">
                    <div className="flex items-center justify-between">
                      <span className="text-xs uppercase text-amber-400 font-bold tracking-widest">
                        {lang === 'hi' ? 'कासगंज की आवाज' : 'Voice of Kasganj'}
                      </span>
                      <span className="text-[11px] px-2 py-0.5 rounded bg-blue-900/80 text-blue-200 font-semibold border border-blue-700">
                        100 - Kasganj
                      </span>
                    </div>
                    <p className="text-xs sm:text-sm font-medium text-slate-200 mt-1">
                      {lang === 'hi'
                        ? 'शिक्षा, स्वास्थ्य, युवा स्वावलंबन और समरसता को समर्पित जीवन।'
                        : 'Life dedicated to universal education, healthcare, youth self-reliance, and equality.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Quick credential badges */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <span className="text-slate-400 block text-[11px] font-medium">
                    {lang === 'hi' ? 'उच्च शिक्षा' : 'Highest Degree'}
                  </span>
                  <span className="font-bold text-slate-800 mt-0.5 block">
                    M.Sc. Mathematics (DBRAU)
                  </span>
                </div>
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                  <span className="text-slate-400 block text-[11px] font-medium">
                    {lang === 'hi' ? 'संस्थापक / संरक्षक' : 'Patron & Founder'}
                  </span>
                  <span className="font-bold text-slate-800 mt-0.5 block">
                    Dr. Ambedkar Trust
                  </span>
                </div>
              </div>
            </div>

            {/* Right Column: About Overview, Pillars & "Read More" CTA */}
            <div className="lg:col-span-7 space-y-6">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 text-xs font-bold text-blue-900 tracking-wider uppercase bg-blue-50 px-3 py-1 rounded-full border border-blue-200">
                  <User className="w-3.5 h-3.5 text-amber-600" />
                  <span>{lang === 'hi' ? 'हमारे बारे में / परिचय' : 'About Us / Profile'}</span>
                </div>
                <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-display text-slate-900 tracking-tight">
                  {lang === 'hi'
                    ? 'कासगंज के विकास और जनसेवा को समर्पित एक सशक्त नेतृत्व'
                    : 'A Dedicated Leadership for Grassroots Welfare & Development in Kasganj'}
                </h2>
                <div className="w-20 h-1 bg-amber-500 rounded-full" />
              </div>

              {/* Executive Summary & Concise Biography */}
              <div className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200 text-slate-700 leading-relaxed space-y-3">
                <p className="text-sm sm:text-base font-normal">
                  {lang === 'hi'
                    ? 'कासगंज (उत्तर प्रदेश) की माटी से गहरा जुड़ाव रखने वाले प्रवीण कुमार मिश्र एक कर्मठ सामाजिक कार्यकर्ता, शिक्षाविद और जनसेवी हैं। डॉ. भीमराव आंबेडकर विश्वविद्यालय, आगरा (DBRAU) से गणित में परास्नातक (M.Sc. Mathematics) उपाधि प्राप्त करने के उपरांत, उन्होंने अपना जीवन जमीनी जनसरोकारों, ग्रामीण अवसंरचना और युवाओं के भविष्य संवारने में समर्पित किया है।'
                    : 'Rooted deeply in Kasganj, Uttar Pradesh, Praveen Kumar Mishra is a devoted grassroots social worker, educationist, and public leader. Holding a Master of Science (M.Sc.) in Mathematics from Dr. Bhimrao Ambedkar University, Agra (DBRAU), he combines analytical acumen with relentless community service.'}
                </p>

                <p className="text-sm sm:text-base font-normal">
                  {lang === 'hi'
                    ? 'डॉ. आंबेडकर ग्रामीण विकास ट्रस्ट (Dr. Ambedkar Gramin Vikas Trust) की समतामूलक विचारधारा और बाबासाहब के सिद्धांतों से प्रेरित होकर, वे गांव-गांव निशुल्क अध्ययन केंद्र, पुस्तकालय श्रृंखला, नियमित स्वास्थ्य शिविर और जनसमस्या निवारण अभियान का सफल नेतृत्व कर रहे हैं।'
                    : 'Deeply inspired by the mission and social justice values of Dr. Ambedkar Gramin Vikas Trust, he champions accessible rural education, free study hubs, village library networks, diagnostic health camps, and grassroots civic grievance redressal across Kasganj.'}
                </p>
              </div>

              {/* 4 Core Pillars Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3.5 rounded-xl bg-amber-50/70 border border-amber-200/80 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center shrink-0 font-bold">
                    <BookOpen className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {lang === 'hi' ? 'सुलभ गुणवत्तापूर्ण शिक्षा' : 'Accessible Quality Education'}
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      {lang === 'hi' ? 'गाँव-गाँव निशुल्क पुस्तकालय व कोचिंग' : 'Village study hubs & competitive coaching'}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-blue-50/70 border border-blue-200/80 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-900 text-white flex items-center justify-center shrink-0 font-bold">
                    <Heart className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {lang === 'hi' ? 'ग्रामीण स्वास्थ्य व चिकित्सा' : 'Rural Health & Diagnostics'}
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      {lang === 'hi' ? 'नियमित मेडिकल शिविर व निशुल्क दवाएं' : 'Free diagnostics, ambulances & checkups'}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-emerald-50/70 border border-emerald-200/80 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shrink-0 font-bold">
                    <TrendingUp className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {lang === 'hi' ? 'युवा रोजगार व स्वावलंबन' : 'Youth Employment & Skills'}
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      {lang === 'hi' ? 'कौशल विकास व कृषि-उद्योग प्रोत्साहन' : 'Skill training, agro-processing & jobs'}
                    </p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-purple-50/70 border border-purple-200/80 flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-900 text-white flex items-center justify-center shrink-0 font-bold">
                    <ShieldCheck className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">
                      {lang === 'hi' ? 'संवैधानिक समरसता व न्याय' : 'Social Justice & Civic Rights'}
                    </h4>
                    <p className="text-[11px] text-slate-600 mt-0.5">
                      {lang === 'hi' ? 'अंतिम व्यक्ति तक जनकल्याणकारी योजनाएं' : 'Upholding equality & direct citizen voice'}
                    </p>
                  </div>
                </div>
              </div>

              {/* Navigation button to Full Dedicated About Page */}
              <div className="pt-3 flex flex-wrap items-center gap-3">
                <button
                  onClick={() => onNavigate('about')}
                  className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-950 hover:bg-blue-900 text-white text-xs sm:text-sm font-bold shadow-lg hover:shadow-xl transition-all cursor-pointer"
                >
                  <span>
                    {lang === 'hi' ? 'सम्पूर्ण जीवन परिचय व पृष्ठभूमि पढ़ें' : 'Read Full Biography & Journey'}
                  </span>
                  <ArrowRight className="w-4 h-4 text-amber-400" />
                </button>
                <button
                  onClick={() => onNavigate('public-role')}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs sm:text-sm font-semibold transition-colors cursor-pointer border border-slate-200"
                >
                  <Award className="w-4 h-4 text-amber-600" />
                  <span>
                    {lang === 'hi' ? 'सार्वजनिक दायित्व व रिकॉर्ड' : 'Public Role & Record'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Impact & Proof By Numbers (Bold High-Contrast Strip) */}
      <section className="py-14 bg-gradient-to-r from-slate-900 via-blue-950 to-slate-900 text-white border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest">
                {lang === 'hi' ? 'जमीनी प्रमाण व आंकड़े' : 'Ground Impact by the Numbers'}
              </span>
              <h3 className="text-2xl sm:text-3xl font-extrabold font-display mt-1">
                {lang === 'hi'
                  ? 'शब्दों से नहीं, काम से प्रमाणित जनसेवा'
                  : 'Demonstrated Impact Across Kasganj'}
              </h3>
            </div>
            <button
              onClick={() => onNavigate('impact-proof')}
              className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
            >
              <span>{lang === 'hi' ? 'सभी सफलता गाथाएं व साक्ष्य देखें' : 'View Verified Proof & Stories'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6">
            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-colors">
              <span className="text-3xl sm:text-4xl font-extrabold text-amber-400 font-display block">
                15,000+
              </span>
              <p className="text-xs sm:text-sm font-bold text-white mt-1">
                {lang === 'hi' ? 'विद्यार्थी व युवा लाभान्वित' : 'Students & Youth Guided'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {lang === 'hi' ? 'निशुल्क पुस्तकें, करियर सेमिनार व परामर्श' : 'Study kits, career guidance & mentorship'}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-colors">
              <span className="text-3xl sm:text-4xl font-extrabold text-blue-400 font-display block">
                50+
              </span>
              <p className="text-xs sm:text-sm font-bold text-white mt-1">
                {lang === 'hi' ? 'निशुल्क स्वास्थ्य शिविर' : 'Free Medical Camps'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {lang === 'hi' ? 'नेत्र जांच, रक्त परीक्षण व दवा वितरण' : 'Health checkups, eye exams & medicine'}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-colors">
              <span className="text-3xl sm:text-4xl font-extrabold text-emerald-400 font-display block">
                120+
              </span>
              <p className="text-xs sm:text-sm font-bold text-white mt-1">
                {lang === 'hi' ? 'ग्राम्य समस्याएं निवारित' : 'Village Grievances Resolved'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {lang === 'hi' ? 'सड़क, पेयजल, बिजली व पेंशन सहायता' : 'Roads, clean water, power & pensions'}
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-colors">
              <span className="text-3xl sm:text-4xl font-extrabold text-purple-400 font-display block">
                2,500+
              </span>
              <p className="text-xs sm:text-sm font-bold text-white mt-1">
                {lang === 'hi' ? 'राहत किट व वस्त्र वितरण' : 'Relief & Winter Care Kits'}
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {lang === 'hi' ? 'बाढ़, शीतकालीन व आपातकालीन सहायता' : 'Flood support, warm clothes & dry ration'}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Kasganj Vision 2027 & Roadmap Teaser */}
      <section className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center max-w-3xl mx-auto space-y-3">
            <div className="inline-flex items-center gap-2 text-xs font-bold text-amber-700 tracking-wider uppercase bg-amber-100 px-3 py-1 rounded-full border border-amber-300">
              <Flag className="w-3.5 h-3.5 text-amber-600" />
              <span>{lang === 'hi' ? 'कासगंज विजन 2027' : 'Vision 2027 for Kasganj'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold font-display text-slate-900 tracking-tight">
              {lang === 'hi'
                ? 'कासगंज 100 विधानसभा क्षेत्र का समग्र विकास संकल्प'
                : 'Strategic Blueprint for Vidhan Sabha 100 Kasganj'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              {lang === 'hi'
                ? 'कृषि, युवा रोजगार, स्वास्थ्य और सड़क अवसंरचना के लिए तैयार किया गया व्यावहारिक 5-सूत्रीय खाका।'
                : 'A pragmatic, data-driven action plan addressing agriculture, industrial jobs, hospitals, and rural connectivity.'}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-shadow space-y-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-700 flex items-center justify-center font-bold">
                <TrendingUp className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                {lang === 'hi' ? 'कृषि मंडी आधुनिकीकरण व फूड प्रोसेसिंग' : 'Modern Agro-Mandi & Food Processing'}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'hi'
                  ? 'कासगंज के किसानों को उनकी फसल का उचित मूल्य दिलाने के लिए कोल्ड स्टोरेज श्रृंखला और सीधी मंडी कनेक्टिविटी।'
                  : 'Modern cold-chain facilities, direct market linkages, and crop value addition for local farmers.'}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-shadow space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-700 flex items-center justify-center font-bold">
                <Heart className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                {lang === 'hi' ? 'जिला स्तरीय सुपर-स्पेशियलिटी स्वास्थ्य' : 'District Super-Specialty Healthcare'}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'hi'
                  ? 'कासगंज में ट्रॉमा सेंटर, विशेषज्ञ डॉक्टरों की उपलब्धता और ग्रामीण प्राथमिक स्वास्थ्य केंद्रों का आधुनिकीकरण।'
                  : 'Advanced trauma facilities, 24/7 specialist availability, and upgraded rural primary health centers.'}
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-xs hover:shadow-md transition-shadow space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-700 flex items-center justify-center font-bold">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                {lang === 'hi' ? 'युवा रोजगार केंद्र व महिला स्वावलंबन' : 'Youth Employment & Women Micro-Hubs'}
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'hi'
                  ? 'आईटी एवं वोकेशनल कौशल केंद्र, स्वयं सहायता समूहों को सूक्ष्म-ऋण और स्थानीय उद्यमिता को बढ़ावा।'
                  : 'Vocational training centers, micro-financing for women self-help groups, and local entrepreneurship hubs.'}
              </p>
            </div>
          </div>

          <div className="flex items-center justify-center gap-4 flex-wrap pt-2">
            <button
              onClick={() => onNavigate('vision-2027')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
            >
              <span>{lang === 'hi' ? 'संपूर्ण विजन 2027 दस्तावेज पढ़ें' : 'Read Full Vision 2027'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('roadmap-2027')}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-800 font-semibold text-xs sm:text-sm border border-slate-300 transition-all cursor-pointer"
            >
              <Calendar className="w-4 h-4 text-amber-600" />
              <span>{lang === 'hi' ? '2027 चुनाव रोडमैप देखें' : 'View 2027 Roadmap'}</span>
            </button>
          </div>
        </div>
      </section>

      {/* 5. Key Initiatives & Social Work Spotlight */}
      <section className="py-16 sm:py-20 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-10">
            <div>
              <span className="text-xs font-bold text-blue-900 uppercase tracking-widest">
                {lang === 'hi' ? 'प्रमुख पहल व समाज सेवा' : 'Key Initiatives & Community Outreach'}
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-display text-slate-900 mt-1">
                {lang === 'hi' ? 'जमीन पर संचालित प्रमुख कार्यक्रम' : 'Flagship Field Programs in Action'}
              </h2>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={() => onNavigate('initiatives')}
                className="text-xs sm:text-sm font-bold text-blue-900 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
              >
                <span>{lang === 'hi' ? 'सभी पहल देखें' : 'View All Initiatives'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Card 1 */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-blue-900 text-white flex items-center justify-center font-bold">
                <BookOpen className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider block">
                  {lang === 'hi' ? 'शिक्षा अभियान' : 'Education Movement'}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {lang === 'hi' ? 'शिक्षा रथ व निशुल्क पुस्तक वितरण' : 'Shiksha Rath & Free Book Bank'}
                </h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'hi'
                  ? 'कासगंज के ग्रामीण अंचलों में आर्थिक रूप से कमजोर बच्चों तक एनसीईआरटी व प्रतियोगी परीक्षाओं की पुस्तकें पहुंचाना।'
                  : 'Delivering NCERT, school supplies, and competitive examination textbooks directly to underprivileged village youth.'}
              </p>
              <button
                onClick={() => onNavigate('initiatives')}
                className="text-xs font-bold text-blue-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer pt-2"
              >
                <span>{lang === 'hi' ? 'विवरण पढ़ें' : 'Learn More'}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Card 2 */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                <Heart className="w-6 h-6" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider block">
                  {lang === 'hi' ? 'स्वास्थ्य सेवा' : 'Healthcare Seva'}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {lang === 'hi' ? 'हर घर स्वास्थ्य जांच शिविर' : 'Har Ghar Swasthya Mobile Camps'}
                </h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'hi'
                  ? 'वरिष्ठ चिकित्सकों के सहयोग से गांवों में मोतियाबिंद ऑपरेशन, बीपी-शुगर जांच व निशुल्क दवाइयां उपलब्ध कराना।'
                  : 'Conducting comprehensive diagnostic checkups, cataract screening, and distributing free medication to seniors.'}
              </p>
              <button
                onClick={() => onNavigate('social-work')}
                className="text-xs font-bold text-blue-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer pt-2"
              >
                <span>{lang === 'hi' ? '10 सेवा क्षेत्र देखें' : 'View 10 Domains'}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            {/* Card 3 */}
            <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200 hover:border-amber-400 transition-all space-y-4">
              <div className="w-12 h-12 rounded-xl bg-purple-900 text-white flex items-center justify-center font-bold">
                <ShieldCheck className="w-6 h-6 text-amber-400" />
              </div>
              <div>
                <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider block">
                  {lang === 'hi' ? 'ट्रस्ट गतिविधि' : 'Trust Activity'}
                </span>
                <h3 className="text-base font-bold text-slate-900 mt-1">
                  {lang === 'hi' ? 'डॉ. आंबेडकर ग्रामीण पुस्तकालय नेटवर्क' : 'Dr. Ambedkar Village Library Network'}
                </h3>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                {lang === 'hi'
                  ? 'गांव-गांव में आधुनिक अध्ययन कक्ष और बाबासाहब के समतावादी विचारों की प्रेरणा देने वाले पुस्तकालयों की स्थापना।'
                  : 'Establishing community study rooms, constitutional literature corners, and youth guidance libraries in rural belts.'}
              </p>
              <button
                onClick={() => onNavigate('ambedkar-trust')}
                className="text-xs font-bold text-blue-900 hover:text-amber-600 flex items-center gap-1 cursor-pointer pt-2"
              >
                <span>{lang === 'hi' ? 'ट्रस्ट रिपोर्ट देखें' : 'View Trust Work'}</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Authentic Photo Gallery & Speeches Preview */}
      <section className="py-16 sm:py-20 bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
            <div>
              <span className="text-xs font-bold text-amber-400 uppercase tracking-widest flex items-center gap-1.5">
                <ImageIcon className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'चित्र दीर्घा एवं वीडियो' : 'Photo Gallery & Media'}</span>
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold font-display text-white mt-1">
                {lang === 'hi' ? 'सार्वजनिक जीवन व जनसंवाद के क्षण' : 'Glimpses of Public Service & Leadership'}
              </h2>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onNavigate('gallery')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
              >
                <span>{lang === 'hi' ? 'पूरी फोटो गैलरी देखें' : 'Full Photo Gallery'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onNavigate('speeches-videos')}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold text-xs border border-white/20 transition-colors cursor-pointer"
              >
                <Video className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'hi' ? 'भाषण एवं वीडियो' : 'Videos'}</span>
              </button>
            </div>
          </div>

          {/* 4 Photo Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div
              onClick={() => onNavigate('public-role')}
              className="group relative rounded-xl overflow-hidden bg-slate-800 border border-slate-700 hover:border-amber-400 transition-all cursor-pointer aspect-[3/4]"
            >
              <img
                src="/WhatsApp Image 2026-02-22 at 2.03.17 PM.jpeg"
                alt="Presidential Meeting"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                style={{ objectPosition: '50% 25%' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent flex flex-col justify-end p-4">
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-wider">
                  {lang === 'hi' ? 'ऐतिहासिक भेंट' : 'Historic Meeting'}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {lang === 'hi'
                    ? 'महामहिम राष्ट्रपति श्री राम नाथ कोविंद जी से भेंट'
                    : 'Meeting with Hon’ble President Ram Nath Kovind'}
                </h4>
              </div>
            </div>

            <div
              onClick={() => onNavigate('gallery')}
              className="group relative rounded-xl overflow-hidden bg-slate-800 border border-slate-700 hover:border-amber-400 transition-all cursor-pointer aspect-[3/4]"
            >
              <img
                src="/eg.jpeg"
                alt="Youth Mentorship"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                style={{ objectPosition: '50% 20%' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent flex flex-col justify-end p-4">
                <span className="text-[10px] font-bold text-blue-400 uppercase tracking-wider">
                  {lang === 'hi' ? 'युवा संवाद' : 'Youth Dialogue'}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {lang === 'hi' ? 'छात्र-छात्राओं को करियर व प्रतियोगी मार्गदर्शन' : 'Mentoring Youth in Kasganj'}
                </h4>
              </div>
            </div>

            <div
              onClick={() => onNavigate('gallery')}
              className="group relative rounded-xl overflow-hidden bg-slate-800 border border-slate-700 hover:border-amber-400 transition-all cursor-pointer aspect-[3/4]"
            >
              <img
                src="/3.png"
                alt="Public Rally"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                style={{ objectPosition: '50% 30%' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent flex flex-col justify-end p-4">
                <span className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">
                  {lang === 'hi' ? 'जनसभा' : 'Public Rally'}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {lang === 'hi' ? 'कासगंज में विशाल जनसंवाद व सभा' : 'Mass Public Address in Kasganj'}
                </h4>
              </div>
            </div>

            <div
              onClick={() => onNavigate('about')}
              className="group relative rounded-xl overflow-hidden bg-slate-800 border border-slate-700 hover:border-amber-400 transition-all cursor-pointer aspect-[3/4]"
            >
              <img
                src="/C7BAR.jpg"
                alt="Leadership Portrait"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                style={{ objectPosition: '50% 15%' }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/30 to-transparent flex flex-col justify-end p-4">
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">
                  {lang === 'hi' ? 'आधिकारिक स्वरूप' : 'Official Portrait'}
                </span>
                <h4 className="text-xs sm:text-sm font-bold text-white mt-0.5">
                  {lang === 'hi' ? 'प्रवीण कुमार मिश्र - संकल्प व निष्ठा' : 'Praveen Kumar Mishra - Dedication'}
                </h4>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. Grassroots Action: Join as Volunteer & Transparent Campaign Fund */}
      <section className="py-16 sm:py-20 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Volunteer Card */}
            <div className="p-8 rounded-2xl bg-gradient-to-br from-blue-900 via-indigo-950 to-blue-950 text-white shadow-xl flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
                  <Users className="w-6 h-6 text-amber-400" />
                </div>
                <h3 className="text-2xl font-bold font-display text-white">
                  {lang === 'hi' ? 'कासगंज के नवनिर्माण में स्वयंसेवक बनें' : 'Join as a Grassroots Volunteer'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {lang === 'hi'
                    ? 'कासगंज विधानसभा क्षेत्र (100) के प्रत्येक वार्ड और गांव तक बदलाव का संदेश पहुंचाने के लिए हमारी युवा व जनसेवा टीम का हिस्सा बनें।'
                    : 'Be part of our field brigade across every booth, village, and ward in Kasganj (100) to advocate for civic rights, education, and development.'}
                </p>
              </div>

              <div>
                <button
                  onClick={() => onNavigate('volunteer')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
                >
                  <span>{lang === 'hi' ? 'स्वयंसेवक फॉर्म भरें' : 'Register as Volunteer'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Campaign Fund Card */}
            <div className="p-8 rounded-2xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 text-slate-950 shadow-xl flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="w-12 h-12 rounded-xl bg-slate-950 text-amber-400 flex items-center justify-center">
                  <QrCode className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold font-display text-slate-950">
                  {lang === 'hi' ? 'चुनावी जनसहयोग - 100% पारदर्शी (UPI)' : 'Grassroots Campaign Fund (UPI)'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-900 leading-relaxed font-medium">
                  {lang === 'hi'
                    ? 'स्वच्छ राजनीति और स्वतंत्र जनसेवा के लिए अपना अमूल्य आर्थिक सहयोग सीधे PhonePe, Google Pay या Paytm UPI QR से प्रदान करें।'
                    : 'Support clean, people-powered grassroots politics through 100% transparent micro-donations via instant UPI QR codes.'}
                </p>
              </div>

              <div>
                <button
                  onClick={() => onNavigate('campaign-fund')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-slate-950 hover:bg-slate-900 text-white font-extrabold text-xs sm:text-sm shadow-md transition-all cursor-pointer"
                >
                  <span>{lang === 'hi' ? 'UPI क्यूआर कोड से सहयोग करें' : 'Contribute via UPI QR'}</span>
                  <ArrowRight className="w-4 h-4 text-amber-400" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. Direct Contact & Office Strip */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-6 sm:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-blue-900 text-amber-400 flex items-center justify-center shrink-0">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  {lang === 'hi' ? 'कासगंज केंद्रीय कार्यालय एवं जनता दरबार' : 'Kasganj Central Office & Janata Darbar'}
                </h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  {lang === 'hi'
                    ? 'कासगंज, उत्तर प्रदेश | प्रतिदिन प्रातः 9:00 बजे से दोपहर 1:00 बजे तक'
                    : 'Kasganj, Uttar Pradesh | Daily 9:00 AM - 1:00 PM for citizen grievances'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                onClick={() => onNavigate('contact')}
                className="px-5 py-2.5 rounded-xl bg-blue-950 hover:bg-blue-900 text-white font-bold text-xs sm:text-sm shadow-sm transition-all cursor-pointer flex items-center gap-2"
              >
                <PhoneCall className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'hi' ? 'सीधा संपर्क करें' : 'Contact Office'}</span>
              </button>
              <button
                onClick={() => onNavigate('public-issues')}
                className="px-4 py-2.5 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
              >
                <span>{lang === 'hi' ? 'जनसमस्या दर्ज करें' : 'File Grievance'}</span>
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
