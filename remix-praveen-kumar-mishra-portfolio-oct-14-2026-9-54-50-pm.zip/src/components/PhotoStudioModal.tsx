import React, { useState, useEffect, useRef } from 'react';
import {
  Sliders,
  Upload,
  Crop,
  ZoomIn,
  Move,
  Save,
  X,
  Image as ImageIcon,
  CheckCircle2,
  RotateCcw,
  Sparkles,
  Layers,
  Award,
  Users,
  Megaphone,
  Briefcase,
  Flag,
  Palette,
} from 'lucide-react';
import { Language, PhotoSettings } from '../types';
import { PHOTO_PRESETS, PhotoPresetItem } from '../data/photoPresets';

export interface PhotoStudioModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  targetSlot?: 'hero' | 'presidential' | 'youth' | 'rally' | 'office' | 'gallery';
  onSaved?: (settings: PhotoSettings, slot: string) => void;
}

export const PhotoStudioModal: React.FC<PhotoStudioModalProps> = ({
  isOpen,
  onClose,
  lang,
  targetSlot: initialSlot = 'hero',
  onSaved,
}) => {
  const [selectedSlot, setSelectedSlot] = useState<string>(initialSlot);
  const [activeTab, setActiveTab] = useState<'presets' | 'upload'>('presets');
  const [selectedPresetId, setSelectedPresetId] = useState<string>('preset-hero-c7bar');
  
  // Photo settings
  const [settings, setSettings] = useState<PhotoSettings>({
    imageUrl: '/nb.jpeg',
    zoom: 105,
    positionX: 50,
    positionY: 25,
    aspectRatio: '3/4',
    shape: 'rounded',
    showGoldBorder: true,
    borderStyle: 'gold',
    captionHi: 'कासगंज के विकास और लोगों की सेवा ही मेरा उद्देश्य है।',
    captionEn: 'Development of Kasganj and service of the people is my sole purpose.',
  });

  const [customFileLoaded, setCustomFileLoaded] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [previewError, setPreviewError] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize from slot or localStorage on modal open
  useEffect(() => {
    if (!isOpen) return;

    setSelectedSlot(initialSlot);
    try {
      const slotKey = `praveen_slot_${initialSlot}`;
      const savedSlot = localStorage.getItem(slotKey);
      if (savedSlot) {
        setSettings(JSON.parse(savedSlot));
        return;
      }

      const matchingPreset = PHOTO_PRESETS.find((p) => p.slot === initialSlot) || PHOTO_PRESETS[0];
      setSelectedPresetId(matchingPreset.id);
      setSettings({
        imageUrl: matchingPreset.svgDataUri,
        zoom: matchingPreset.defaultZoom,
        positionX: matchingPreset.defaultPositionX,
        positionY: matchingPreset.defaultPositionY,
        aspectRatio: matchingPreset.defaultAspectRatio,
        shape: matchingPreset.shape,
        showGoldBorder: matchingPreset.showGoldBorder,
        borderStyle: matchingPreset.borderStyle,
        captionHi: matchingPreset.quoteHi,
        captionEn: matchingPreset.quoteEn,
      });
    } catch {
      // fallback
    }
  }, [isOpen, initialSlot]);

  if (!isOpen) return null;

  // Handle switching slot
  const handleSlotChange = (slotId: string) => {
    setSelectedSlot(slotId);
    try {
      const slotKey = `praveen_slot_${slotId}`;
      const savedSlot = localStorage.getItem(slotKey);
      if (savedSlot) {
        setSettings(JSON.parse(savedSlot));
        return;
      }
    } catch {}

    const matchingPreset = PHOTO_PRESETS.find((p) => p.slot === slotId) || PHOTO_PRESETS[0];
    setSelectedPresetId(matchingPreset.id);
    setSettings({
      imageUrl: matchingPreset.svgDataUri,
      zoom: matchingPreset.defaultZoom,
      positionX: matchingPreset.defaultPositionX,
      positionY: matchingPreset.defaultPositionY,
      aspectRatio: matchingPreset.defaultAspectRatio,
      shape: matchingPreset.shape,
      showGoldBorder: matchingPreset.showGoldBorder,
      borderStyle: matchingPreset.borderStyle,
      captionHi: matchingPreset.quoteHi,
      captionEn: matchingPreset.quoteEn,
    });
  };

  // Handle selecting a preset
  const handleSelectPreset = (preset: PhotoPresetItem) => {
    setSelectedPresetId(preset.id);
    setCustomFileLoaded(false);
    setPreviewError(false);
    setSettings((prev) => ({
      ...prev,
      imageUrl: preset.svgDataUri,
      zoom: preset.defaultZoom,
      positionX: preset.defaultPositionX,
      positionY: preset.defaultPositionY,
      aspectRatio: preset.defaultAspectRatio,
      shape: preset.shape,
      showGoldBorder: preset.showGoldBorder,
      borderStyle: preset.borderStyle,
      captionHi: preset.quoteHi,
      captionEn: preset.quoteEn,
    }));
  };

  // Handle custom file upload from device
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    const reader = new FileReader();

    reader.onload = async () => {
      const base64 = reader.result as string;
      setCustomFileLoaded(true);
      setPreviewError(false);
      setSettings((prev) => ({
        ...prev,
        imageUrl: base64,
      }));

      try {
        await fetch('/api/upload-photo', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64,
            filename: file.name,
            slot: selectedSlot,
            settings: { ...settings, imageUrl: base64 },
          }),
        });
      } catch (err) {
        console.warn('Optional backend sync warning:', err);
      } finally {
        setIsUploading(false);
      }
    };

    reader.readAsDataURL(file);
  };

  // Save changes
  const handleSave = async () => {
    try {
      localStorage.setItem(`praveen_slot_${selectedSlot}`, JSON.stringify(settings));

      if (selectedSlot === 'hero') {
        localStorage.setItem('praveen_portrait_settings', JSON.stringify(settings));
        if (settings.imageUrl) {
          localStorage.setItem('praveen_portrait_url', settings.imageUrl);
        }
      }

      if (settings.imageUrl.startsWith('data:image')) {
        try {
          await fetch('/api/upload-photo', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              imageBase64: settings.imageUrl,
              filename: `${selectedSlot}.jpg`,
              slot: selectedSlot,
              settings,
            }),
          });
        } catch {}
      }

      window.dispatchEvent(
        new CustomEvent('praveen_photo_updated', {
          detail: { slot: selectedSlot, settings },
        })
      );

      if (onSaved) {
        onSaved(settings, selectedSlot);
      }

      setSavedSuccess(true);
      setTimeout(() => {
        setSavedSuccess(false);
        onClose();
      }, 1000);
    } catch (err) {
      console.error('Error saving photo settings:', err);
    }
  };

  const slotsList = [
    {
      id: 'hero',
      labelEn: 'Hero Portrait',
      labelHi: 'मुख्य परिचय (Hero)',
      icon: Award,
    },
    {
      id: 'presidential',
      labelEn: 'Presidential Meeting',
      labelHi: 'महामहिम राष्ट्रपति भेंट',
      icon: Flag,
    },
    {
      id: 'youth',
      labelEn: 'Youth Mentorship',
      labelHi: 'युवा संवाद व शिक्षा',
      icon: Users,
    },
    {
      id: 'rally',
      labelEn: 'Kasganj Rally Address',
      labelHi: 'कासगंज विशाल जनसभा',
      icon: Megaphone,
    },
    {
      id: 'office',
      labelEn: 'Executive Vision',
      labelHi: 'कार्यालय एवं सिद्धांत',
      icon: Briefcase,
    },
  ];

  const aspectRatios = [
    { id: '3/4', label: '3:4 (Portrait)' },
    { id: '1/1', label: '1:1 (Square)' },
    { id: '4/3', label: '4:3 (Meeting)' },
    { id: '16/9', label: '16:9 (Banner)' },
    { id: '9/16', label: '9:16 (Story)' },
    { id: '2/3', label: '2:3 (Tall)' },
  ];

  const getAspectClass = () => {
    switch (settings.aspectRatio) {
      case '1/1':
        return 'aspect-square';
      case '4/3':
        return 'aspect-4/3';
      case '16/9':
        return 'aspect-16/9';
      case '9/16':
        return 'aspect-[9/16]';
      case '2/3':
        return 'aspect-2/3';
      case '3/4':
      default:
        return 'aspect-3/4';
    }
  };

  const getBorderClass = () => {
    if (!settings.showGoldBorder) return 'border border-slate-700';
    if (settings.borderStyle === 'tricolor') {
      return 'border-2 border-amber-500 shadow-2xl ring-2 ring-emerald-500/40 shadow-orange-500/20';
    }
    if (settings.borderStyle === 'navy') {
      return 'border-2 border-blue-500/80 shadow-2xl shadow-blue-500/20';
    }
    return 'border-2 border-amber-400/90 shadow-2xl shadow-amber-400/25';
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-950/85 backdrop-blur-md overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-amber-500/40 rounded-3xl max-w-5xl w-full p-5 sm:p-7 shadow-2xl my-6 text-white max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-amber-500 to-amber-300 text-slate-950 flex items-center justify-center font-bold shadow-lg">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg sm:text-xl font-bold font-display text-white">
                  {lang === 'hi' ? 'फोटो स्टूडियो एवं आकार चयनकर्ता' : 'Portfolio Photo Studio & Framing Manager'}
                </h3>
                <span className="text-[10px] font-bold text-amber-300 bg-amber-500/20 border border-amber-400/30 px-2 py-0.5 rounded-full uppercase tracking-wider">
                  7 Authentic Presets
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {lang === 'hi'
                  ? 'अपनी पसंदीदा फोटो चुनें या अपलोड करें, और मनचाहा आकार व फ्रेमिंग सेट करें'
                  : 'Select any authentic image, upload custom photo, and adjust aspect ratio & size'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close Modal"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Slot Selector Ribbon */}
        <div className="py-3 border-b border-slate-800/80 shrink-0">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'hi' ? '१. वेबसाइट पर लगाने का स्थान (Target Slot):' : '1. Choose Target Slot on Website:'}</span>
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {slotsList.map((slot) => {
              const Icon = slot.icon;
              const isSelected = selectedSlot === slot.id;
              return (
                <button
                  key={slot.id}
                  type="button"
                  onClick={() => handleSlotChange(slot.id)}
                  className={`p-2 rounded-xl text-left transition-all border cursor-pointer flex items-center gap-2 ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-400 text-white shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Icon className={`w-4 h-4 shrink-0 ${isSelected ? 'text-amber-400' : 'text-slate-500'}`} />
                  <div className="min-w-0">
                    <p className="text-xs font-bold truncate">
                      {lang === 'hi' ? slot.labelHi : slot.labelEn}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Modal Body */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-4 flex-1 overflow-y-auto">
          {/* Controls Column */}
          <div className="lg:col-span-7 space-y-4 pr-1">
            {/* Step 2: Source Tab */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  {lang === 'hi' ? '२. चित्र चयन या अपलोड (Photo Source):' : '2. Photo Selection / Upload:'}
                </span>

                <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                  <button
                    type="button"
                    onClick={() => setActiveTab('presets')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      activeTab === 'presets'
                        ? 'bg-amber-400 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {lang === 'hi' ? 'उपलब्ध ७ फोटो (Presets)' : '7 Authentic Presets'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('upload')}
                    className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                      activeTab === 'upload'
                        ? 'bg-amber-400 text-slate-950'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Upload className="w-3 h-3" />
                    <span>{lang === 'hi' ? 'फ़ाइल अपलोड करें' : 'Upload File'}</span>
                  </button>
                </div>
              </div>

              {/* Presets Tab Content */}
              {activeTab === 'presets' && (
                <div className="space-y-2">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-56 overflow-y-auto pr-1">
                    {PHOTO_PRESETS.map((preset) => {
                      const isChosen = selectedPresetId === preset.id && !customFileLoaded;
                      return (
                        <div
                          key={preset.id}
                          onClick={() => handleSelectPreset(preset)}
                          className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                            isChosen
                              ? 'bg-blue-950/80 border-amber-400 ring-1 ring-amber-400/50 shadow-md'
                              : 'bg-slate-950/70 border-slate-800/90 hover:border-slate-700'
                          }`}
                        >
                          <div className="w-14 h-14 rounded-lg overflow-hidden shrink-0 border border-white/10 bg-slate-900 relative">
                            <img
                              src={preset.svgDataUri}
                              alt={preset.nameEn}
                              className="w-full h-full object-cover"
                            />
                            {isChosen && (
                              <div className="absolute inset-0 bg-amber-500/20 flex items-center justify-center">
                                <CheckCircle2 className="w-4 h-4 text-amber-400" />
                              </div>
                            )}
                          </div>
                          <div className="min-w-0 flex-1">
                            <h4 className="text-xs font-bold text-white truncate">
                              {lang === 'hi' ? preset.nameHi : preset.nameEn}
                            </h4>
                            <p className="text-[10px] text-amber-300 font-mono mt-0.5">
                              {preset.filename} • {preset.defaultAspectRatio}
                            </p>
                            <p className="text-[10px] text-slate-400 line-clamp-1 italic mt-0.5">
                              "{preset.quoteHi}"
                            </p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Upload Tab Content */}
              {activeTab === 'upload' && (
                <div className="p-4 rounded-2xl bg-slate-950 border border-dashed border-amber-500/40 text-center space-y-3">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                  <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-400/30 text-amber-400 flex items-center justify-center mx-auto">
                    <Upload className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xs sm:text-sm font-bold text-white">
                      {lang === 'hi' ? 'कंप्यूटर या मोबाइल से फोटो अपलोड करें' : 'Upload Image from Computer or Mobile'}
                    </h4>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {lang === 'hi'
                        ? '3.png, 9.png, C7BAR.jpg, eg.jpeg, pp.jpeg या अपनी कोई भी नई फोटो चुनें'
                        : 'Supports PNG, JPG, JPEG, WebP. Real-time persistent storage.'}
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="py-2.5 px-6 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold text-xs inline-flex items-center gap-2 cursor-pointer shadow-md transition-all"
                  >
                    <Upload className="w-4 h-4" />
                    <span>
                      {isUploading
                        ? lang === 'hi'
                          ? 'अपलोड हो रही है...'
                          : 'Processing Upload...'
                        : lang === 'hi'
                        ? 'डिवाइस से फ़ाइल चुनें'
                        : 'Choose File from Device'}
                    </span>
                  </button>

                  {customFileLoaded && (
                    <div className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold bg-emerald-950/60 border border-emerald-500/40 px-3 py-1 rounded-full">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{lang === 'hi' ? 'कस्टम फोटो सफलतापूर्वक लोड हुई!' : 'Custom photo loaded successfully!'}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Step 3: Aspect Ratio Selection */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Crop className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'hi' ? '३. फ्रेम अनुपात (Aspect Ratio & Sizing):' : '3. Frame Aspect Ratio & Sizing:'}</span>
                </span>
                <span className="text-[11px] font-mono text-amber-400 font-bold">
                  {settings.aspectRatio}
                </span>
              </label>

              <div className="grid grid-cols-3 sm:grid-cols-6 gap-1.5">
                {aspectRatios.map((item) => (
                  <button
                    type="button"
                    key={item.id}
                    onClick={() =>
                      setSettings((prev) => ({ ...prev, aspectRatio: item.id as any }))
                    }
                    className={`p-2 rounded-xl text-center text-xs font-bold transition-all border cursor-pointer ${
                      settings.aspectRatio === item.id
                        ? 'bg-amber-400 text-slate-950 border-amber-400 shadow-md'
                        : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                    }`}
                  >
                    <span className="block text-[11px] font-mono">{item.id}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Step 4: Zoom & Focus Controls */}
            <div className="space-y-3 pt-2 border-t border-slate-800">
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <label className="font-semibold text-slate-300 flex items-center gap-1.5">
                    <ZoomIn className="w-3.5 h-3.5 text-amber-400" />
                    <span>{lang === 'hi' ? 'आकार / जूम स्केल (Zoom Scale):' : 'Zoom Scale:'}</span>
                  </label>
                  <span className="font-mono text-amber-300 font-bold">{settings.zoom}%</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="180"
                  step="2"
                  value={settings.zoom}
                  onChange={(e) =>
                    setSettings((prev) => ({ ...prev, zoom: Number(e.target.value) }))
                  }
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                />
                <div className="flex items-center gap-1.5 pt-1">
                  {[
                    { label: '85% Wide', val: 85 },
                    { label: '100% Fit', val: 100 },
                    { label: '115% Portrait', val: 115 },
                    { label: '135% Close-up', val: 135 },
                  ].map((z) => (
                    <button
                      key={z.val}
                      type="button"
                      onClick={() => setSettings((prev) => ({ ...prev, zoom: z.val }))}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-medium border cursor-pointer ${
                        settings.zoom === z.val
                          ? 'bg-amber-400 text-slate-950 border-amber-400'
                          : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                      }`}
                    >
                      {z.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Sliders: Pan X & Y */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-semibold">{lang === 'hi' ? 'क्षैतिज स्थिति (X Focus)' : 'Horizontal (X)'}</span>
                    <span className="font-mono text-amber-400 text-[11px]">{settings.positionX}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="2"
                    value={settings.positionX}
                    onChange={(e) =>
                      setSettings((prev) => ({ ...prev, positionX: Number(e.target.value) }))
                    }
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 font-semibold">{lang === 'hi' ? 'ऊर्ध्वाधर स्थिति (Y Focus)' : 'Vertical (Y)'}</span>
                    <span className="font-mono text-amber-400 text-[11px]">{settings.positionY}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="2"
                    value={settings.positionY}
                    onChange={(e) =>
                      setSettings((prev) => ({ ...prev, positionY: Number(e.target.value) }))
                    }
                    className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>
              </div>

              {/* Quick Position Alignment Presets */}
              <div className="flex items-center gap-1.5 flex-wrap text-[10px]">
                <span className="text-slate-400 font-medium">{lang === 'hi' ? 'त्वरित फोकस:' : 'Quick Focus:'}</span>
                <button
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, positionX: 50, positionY: 25 }))}
                  className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-amber-300 hover:border-amber-400 cursor-pointer font-medium"
                >
                  {lang === 'hi' ? 'चेहरा / सिर फोकस (50%, 25%)' : 'Head / Face (50%, 25%)'}
                </button>
                <button
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, positionX: 50, positionY: 50 }))}
                  className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:border-amber-400 cursor-pointer font-medium"
                >
                  {lang === 'hi' ? 'पूर्ण केंद्र (50%, 50%)' : 'Center (50%, 50%)'}
                </button>
                <button
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, positionX: 30, positionY: 35 }))}
                  className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:border-amber-400 cursor-pointer font-medium"
                >
                  {lang === 'hi' ? 'बायां भाग' : 'Left Align'}
                </button>
                <button
                  type="button"
                  onClick={() => setSettings((prev) => ({ ...prev, positionX: 70, positionY: 35 }))}
                  className="px-2 py-0.5 rounded bg-slate-950 border border-slate-800 text-slate-300 hover:border-amber-400 cursor-pointer font-medium"
                >
                  {lang === 'hi' ? 'दायां भाग' : 'Right Align'}
                </button>
              </div>
            </div>

            {/* Step 5: Border & Styling */}
            <div className="space-y-2 pt-2 border-t border-slate-800">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'hi' ? '५. बॉर्डर व फ्रेम शैली:' : '5. Border & Frame Styling:'}</span>
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() =>
                    setSettings((prev) => ({ ...prev, shape: 'rounded', showGoldBorder: true, borderStyle: 'gold' }))
                  }
                  className={`p-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    settings.shape === 'rounded' && settings.borderStyle === 'gold'
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {lang === 'hi' ? 'स्वर्णिम कार्ड (Gold Frame)' : 'Gold Border Card'}
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setSettings((prev) => ({ ...prev, shape: 'rounded', showGoldBorder: true, borderStyle: 'tricolor' }))
                  }
                  className={`p-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    settings.borderStyle === 'tricolor'
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {lang === 'hi' ? 'तिरंगा किनारा (Tricolor Rim)' : 'Tricolor Rim'}
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setSettings((prev) => ({ ...prev, shape: 'circle', showGoldBorder: true, borderStyle: 'gold' }))
                  }
                  className={`p-2 rounded-xl text-xs font-bold transition-all border cursor-pointer ${
                    settings.shape === 'circle'
                      ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                      : 'bg-slate-950 border-slate-800 text-slate-400'
                  }`}
                >
                  {lang === 'hi' ? 'गोल पदक (Circular Medal)' : 'Circular Medal'}
                </button>
              </div>
            </div>
          </div>

          {/* Live Preview Column */}
          <div className="lg:col-span-5 flex flex-col items-center justify-start bg-slate-950/70 p-4 sm:p-5 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between w-full mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{lang === 'hi' ? 'लाइव पूर्वावलोकन (Live Preview)' : 'Live Preview'}</span>
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Slot: <span className="text-white font-bold">{selectedSlot}</span>
              </span>
            </div>

            <div className="w-full max-w-sm flex items-center justify-center p-2">
              <div
                className={`w-full relative overflow-hidden bg-slate-950 transition-all ${getAspectClass()} ${
                  settings.shape === 'circle' ? 'rounded-full' : 'rounded-2xl'
                } ${getBorderClass()}`}
              >
                <img
                  src={settings.imageUrl}
                  alt="Praveen Kumar Mishra"
                  onError={() => setPreviewError(true)}
                  className="w-full h-full object-cover transition-transform duration-100"
                  style={{
                    transform: `scale(${settings.zoom / 100})`,
                    objectPosition: `${settings.positionX}% ${settings.positionY}%`,
                  }}
                  referrerPolicy="no-referrer"
                />

                {settings.shape !== 'circle' && (
                  <div className="absolute bottom-2 inset-x-2 text-center p-2 bg-slate-950/85 backdrop-blur-md rounded-xl border border-white/10 shadow-lg">
                    <h5 className="text-white font-bold text-xs truncate">
                      Praveen Kumar Mishra (प्रवीण कुमार मिश्र)
                    </h5>
                    <p className="text-amber-400 text-[10px] font-medium truncate mt-0.5">
                      100 - Kasganj Vidhan Sabha Kshetra
                    </p>
                  </div>
                )}

                {previewError && (
                  <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center p-4 text-center text-xs text-amber-200">
                    <ImageIcon className="w-8 h-8 text-amber-400 mb-2" />
                    <span>कृपया प्रीसेट चुनें या डिवाइस से फोटो लोड करें।</span>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-slate-900 border border-slate-800 text-center w-full">
              <p className="text-xs font-semibold text-amber-200/90 italic">
                "{settings.captionHi || 'कासगंज की जनसेवा को समर्पित'}"
              </p>
              <p className="text-[11px] text-slate-400 mt-1">
                {lang === 'hi'
                  ? 'सहेजने पर यह फोटो पूरी वेबसाइट पर तुरंत सक्रिय हो जाएगी।'
                  : 'Changes apply immediately across all portfolio sections.'}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 shrink-0 mt-4">
          <button
            type="button"
            onClick={() => {
              const matchingPreset = PHOTO_PRESETS.find((p) => p.slot === selectedSlot) || PHOTO_PRESETS[0];
              handleSelectPreset(matchingPreset);
            }}
            className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs flex items-center gap-1.5 cursor-pointer transition-colors"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{lang === 'hi' ? 'डिफ़ॉल्ट रीसेट करें' : 'Reset Slot Defaults'}</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs cursor-pointer transition-colors"
            >
              {lang === 'hi' ? 'बंद करें' : 'Close'}
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-amber-300 to-amber-400 hover:brightness-110 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 cursor-pointer transition-all"
            >
              {savedSuccess ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-900" />
                  <span>{lang === 'hi' ? 'सफलतापूर्वक लागू व सहेजा गया!' : 'Successfully Applied & Saved!'}</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>{lang === 'hi' ? 'पोर्टफोलियो में फोटो व आकार लागू करें' : 'Apply & Save to Portfolio'}</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
