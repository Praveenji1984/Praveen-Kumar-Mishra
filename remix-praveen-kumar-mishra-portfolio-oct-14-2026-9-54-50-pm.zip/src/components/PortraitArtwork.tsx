import React, { useState, useEffect } from 'react';
import { PhotoSettings, DEFAULT_PHOTO_SETTINGS } from '../types';
import { PHOTO_PRESETS } from '../data/photoPresets';

export interface PortraitProps {
  type:
    | 'hero'
    | 'presidential'
    | 'youth'
    | 'rally'
    | 'office'
    | 'elder'
    | 'team'
    | 'banner'
    | 'harmony'
    | 'public_hearing'
    | 'gallery';
  className?: string;
  customSrc?: string;
  alt?: string;
  settings?: PhotoSettings;
  showCaption?: boolean;
}

export const PortraitArtwork: React.FC<PortraitProps> = ({
  type,
  className = '',
  customSrc,
  alt = 'Praveen Kumar Mishra - Social Worker & Public Leader',
  settings: propSettings,
  showCaption = true,
}) => {
  // Find matching default preset for this type
  const matchingPreset =
    PHOTO_PRESETS.find((p) => p.slot === type || p.category === type) ||
    PHOTO_PRESETS[0];

  const getInitialSettings = (): PhotoSettings => {
    if (propSettings) return propSettings;

    try {
      const slotKey = `praveen_slot_${type}`;
      const savedSlot = localStorage.getItem(slotKey);
      if (savedSlot) {
        return JSON.parse(savedSlot);
      }

      if (type === 'hero') {
        const savedHero = localStorage.getItem('praveen_portrait_settings');
        if (savedHero) return JSON.parse(savedHero);
      }
    } catch {
      // fallback
    }

    return {
      imageUrl: matchingPreset.svgDataUri,
      zoom: matchingPreset.defaultZoom,
      positionX: matchingPreset.defaultPositionX,
      positionY: matchingPreset.defaultPositionY,
      aspectRatio: matchingPreset.defaultAspectRatio,
      shape: matchingPreset.shape,
      showGoldBorder: matchingPreset.showGoldBorder,
      borderStyle: matchingPreset.borderStyle,
      captionHi: matchingPreset.quoteHi,
      captionEn: matchingPreset.quoteEn,
    };
  };

  const [photoSettings, setPhotoSettings] = useState<PhotoSettings>(getInitialSettings);
  const [imgFailed, setImgFailed] = useState(false);

  // Sync when propSettings changes
  useEffect(() => {
    if (propSettings) {
      setPhotoSettings(propSettings);
      setImgFailed(false);
    }
  }, [propSettings]);

  // Listen to live photo update events dispatched from PhotoStudioModal
  useEffect(() => {
    const handlePhotoUpdated = (e: Event) => {
      const customEvent = e as CustomEvent<{ slot: string; settings: PhotoSettings }>;
      if (customEvent.detail) {
        const { slot, settings } = customEvent.detail;
        if (slot === type || (slot === 'hero' && type === 'hero')) {
          setPhotoSettings(settings);
          setImgFailed(false);
        }
      }
    };

    window.addEventListener('praveen_photo_updated', handlePhotoUpdated);
    return () => {
      window.removeEventListener('praveen_photo_updated', handlePhotoUpdated);
    };
  }, [type]);

  // If a custom static src is explicitly passed
  if (customSrc) {
    return (
      <img
        src={customSrc}
        alt={alt}
        className={`object-cover ${className}`}
        referrerPolicy="no-referrer"
      />
    );
  }

  // Active image url, fallback to preset SVG if custom failed or empty
  const activeUrl = imgFailed
    ? matchingPreset.svgDataUri
    : photoSettings.imageUrl || matchingPreset.svgDataUri;

  // Determine border styles
  const getBorderClass = () => {
    if (!photoSettings.showGoldBorder) return 'border border-slate-700/60';
    switch (photoSettings.borderStyle) {
      case 'tricolor':
        return 'border-3 border-orange-500 shadow-2xl shadow-orange-500/20';
      case 'navy':
        return 'border-2 border-blue-400/80 shadow-2xl shadow-blue-500/10';
      case 'none':
        return 'border-0';
      case 'gold':
      default:
        return 'border-2 border-amber-400/80 shadow-2xl shadow-amber-400/15';
    }
  };

  const getShapeClass = () => {
    if (photoSettings.shape === 'circle') return 'rounded-full aspect-square';
    if (photoSettings.shape === 'card') return 'rounded-lg';
    return 'rounded-2xl';
  };

  return (
    <div
      className={`relative overflow-hidden bg-slate-950 flex items-center justify-center ${getShapeClass()} ${getBorderClass()} ${className}`}
    >
      {/* Background glow */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent z-10 pointer-events-none opacity-60" />

      {/* Main Image with Zoom and Position styling */}
      <img
        src={activeUrl}
        alt={alt}
        onError={() => {
          if (!imgFailed) {
            setImgFailed(true);
          }
        }}
        className="w-full h-full object-cover transition-transform duration-200"
        style={{
          transform: `scale(${photoSettings.zoom / 100})`,
          objectPosition: `${photoSettings.positionX}% ${photoSettings.positionY}%`,
        }}
        referrerPolicy="no-referrer"
      />

      {/* Optional Overlay Banner for hero/presidential when caption is desired */}
      {showCaption && type === 'hero' && (
        <div className="absolute bottom-2 inset-x-3 z-20 text-center px-3 py-1.5 bg-slate-950/85 backdrop-blur-md rounded-xl border border-white/10 shadow-lg pointer-events-none">
          <h4 className="text-white font-bold text-xs sm:text-sm tracking-wide">
            Praveen Kumar Mishra
          </h4>
          <p className="text-amber-400 text-[10px] font-medium">
            100 - Kasganj Vidhan Sabha (कासगंज 100)
          </p>
        </div>
      )}

      {showCaption && type === 'presidential' && (
        <div className="absolute bottom-2 inset-x-3 z-20 text-center px-2.5 py-1 bg-slate-950/90 backdrop-blur-md rounded-lg border border-amber-500/30 shadow-lg pointer-events-none">
          <p className="text-[10px] text-amber-300 font-bold truncate">
            पूर्व राष्ट्रपति श्री रामनाथ कोविंद जी के साथ
          </p>
        </div>
      )}
    </div>
  );
};
